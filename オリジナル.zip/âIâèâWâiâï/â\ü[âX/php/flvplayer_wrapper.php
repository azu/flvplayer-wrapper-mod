<?php
//165氏の発想をもとに、Opera9で動くことを前提としていろいろいじった。
//php5.2.3(cgi版)+なんかそれに付属してきたmingで動作確認
//オブジェクトとかクラスとか理解していない素人です

ming_setscale(20.0);
ming_useswfversion(6);
mb_internal_encoding('UTF-8');

$movie = new SWFMovie();
$movie->setRate(60);
$movie->setBackground(0xff,0xff,0xff);
$movie->setDimension(952,540-60);

function addImageToMovie($clip,$name,$img,$x,$y){
	$image = new SWFBitmap(fopen($img, "rb"));
	$sp = new SWFSprite();
	$sp->add($image);
	$sp->nextFrame();
	$a = $clip->add($sp);
	$a->setName($name);
	$a->moveTo($x,$y);
}

//function makeShapeWithImage($img){
	//引数 jpeg画像までの相対パス
	//イメージそのままボタンにできないらしいので、同サイズshapeに画像をいれる
//	$bmp = new SWFBitmap(fopen($img,"rb"));
//	$w = $bmp->getWidth();
//	$h = $bmp->getHeight();
//	$shape = new SWFShape();
//	$fill = $shape->addFill($bmp);
//	$shape->setRightFill($fill);
//	$shape->movePenTo(0,0);
//	$shape->drawLineTo($w,0);
//	$shape->drawLineTo($w,$h);
//	$shape->drawLineTo(0,$h);
//	$shape->drawLineTo(0,0);
//	return $shape;
//}

//function addButtonToMovie($clip,$name,$up_img,$over_img,$down_img,$hit_img,$script,$x,$y){
//	$up = makeShapeWithImage($up_img);
//	$over = makeShapeWithImage($over_img);
//	$down = makeShapeWithImage($down_img);
//	$hit = makeShapeWithImage($hit_img);
//	$button = new SWFButton();
//	$button->setUp($up);
//	$button->setOver($over);
//	$button->setDown($down);
//	$button->setHit($hit);
//	$button->setAction(new SWFAction($script));
//	$a = $clip->add($button);
//	$a->moveTo($x,$y);
//	$a->setName($name);
//}

//■■■■■■■■■■■■■■メインバー■■■■■■■■■■■■■■
$mb_sp = new SWFSprite();
addImageToMovie($mb_sp, "base", "../image/main_bar.png",0,0);
addImageToMovie($mb_sp, "icon_local", "../image/local.png",0,0);
$mb_sp->nextFrame();
$mb_clip = $movie->add($mb_sp);
$mb_clip->setName("main_bar");
$mb_clip->moveTo(0,0);

//■■■■■■■■■■■■■■NGIDメニュー■■■■■■■■■■■■■■
$nm_sp = new SWFSprite();
addImageToMovie($nm_sp, "base", "../image/ngid_menu.jpg",0,0);
$nm_sp->nextFrame();
$nm_clip=$movie->add($nm_sp);
$nm_clip->setName("ngid_menu");
$nm_clip->moveTo(80,67);

//■■■■■■■■■■■■■■設定メニュー■■■■■■■■■■■■■■
$pm_sp = new SWFSprite();
addImageToMovie($pm_sp, "base", "../image/pref_menu.jpg",0,0);

$pm_sp->nextFrame();
$pm_clip=$movie->add($pm_sp);
$pm_clip->setName("pref_menu");
$pm_clip->moveTo(100,68);

//■■■■■■■■■■■■■■スクリーン■■■■■■■■■■■■■■
$sc_sp = new SWFSprite();
$sc_sp->nextFrame();
$sc_clip=$movie->add($sc_sp);
$sc_clip->setName("screen");
$sc_clip->moveTo(3,41);

//■■■■■■■■■■■■■■ログリスト周辺■■■■■■■■■■■■■■
$ll_sp = new SWFSprite();
addImageToMovie($ll_sp, "tab", "../image/tab.png",0,0);
$ll_sp->nextFrame();
$ll_clip=$movie->add($ll_sp);
$ll_clip->setName("loglist_menu");
$ll_clip->moveTo(549,38);

//■■■■■■■■■■■■■■リンク■■■■■■■■■■■■■■
$al_sp = new SWFSprite();
addImageToMovie($al_sp, "base", "../image/auto_link.jpg",0,0);
addImageToMovie($al_sp, "ameba", "../image/ameba.png",0,0);
addImageToMovie($al_sp, "photozou", "../image/photozou.png",0,0);
$al_sp->nextFrame();
$al_clip=$movie->add($al_sp);
$al_clip->setName("link_thumb");
$al_clip->moveTo(549,290);

//■■■■■■■■■■■■■■メインのアクションスクリプト■■■■■■■■■■■■■■

$MainScript = <<<EOT

var VIDEO;
if(v != undefined){
	VIDEO = v;
}else if(wv != undefined){
	VIDEO = wv.substring(wv.lastIndexOf("sm"),wv.lastIndexOf(".flv"));
}
var AD = ad;
var US = us;

//↓↓↓↓↓↓フィルター処理関連↓↓↓↓↓↓
//カスタムフィルターの処理を何番のコメントまでやったか
var custom_filter_message_count=0;
//nico.Messages[i]がフィルタにかかったらfilter_flag[i]にtrueいれとく
var filter1_flag = new Array();
var filter2_flag = new Array();
var filter3_flag = new Array();
var filter4_flag = new Array();
//NGID処理を何番のコメントまでやったか
var ngid_filter_message_count=0;
//nico.Messages[n]がIDフィルターかかったらngid_filter_flag[n]にtrueいれとく
var ngid_filter_flag = new Array();
var filter_count=0;//フィルタかかってる数(合計)
var filter1_count=0;//フィルタかかってる個別の数
var filter2_count=0;
var filter3_count=0;
var filter4_count=0;
var ngid_filter_count=0;

//↓↓↓↓↓↓ID処理関連↓↓↓↓↓↓
var fwMessages = new Array();
//fwMessages[n].フィールド名
//nico.Messages[n]に整形されてしまう前のxmlデータから抜き出した配列
//アンダーバーがついてるやつはnico.Messagesと一緒
//no      fwMessages[n] もしくは nico.Messages[n]のnと同じ数字が入るはず
//↑バイナリサーチでfwMessagesをuser_idでソートしたあと、元のnが分かるように
//いろいろ面倒なので実際はfwMessages.slice()でコピーしてからソートしたほうがいいかも
//_no      = nico.Messages[n]._no
//_message = nico.Messages[n]._message
//_vpos    = nico.Messages[n]._vpos(ただし動画の最後3秒ぐらいは違う)
//user_id  = chatノードのuser_id 
//vpos     = chatノードのvpos (_vposは秒　vpos = _vpos * 100)
//date     = chatノードのdate
//premium  = chatノードのpremium
//mail     = chatノードのmail
//name     = chatノードのname なぜかまだある(今はコメント０の時の頭の警告メッセージしか使ってないっぽい)
//thread   = chatノードのthread
//コメントが０の時のfwMessagesとnico.Messagesはいろいろ違う
//fwMessagesは空で、nico.Messagesは
//nico.Messages[0]にコメントナンバー0,ID0のコメントが1個入っている
//メッセージをいじる時(_mineや_deletedや_slot)以外はfwMessagesから参照したほうがいいかも
//全コメント検索の時とかは、nico.Messages.lengthよりfwMessages.lengthでカウントするとか
//コメント０の時のテストはいまいちやってないので、これ以上は不明

var ng_ids = new Array();//NGIDいれとくところ
//ng_idsは新着メッセージの検索処理を最優先させるために、常にuser_idの小さい順にソートしておく
//↑ng_ids[n].フィールド名
//user_id ID
//date    最後にヒットした時のgetTime()
//message 最後にヒットしたコメント内容
var cand_ng_id = new Array();//強調表示中のIDのコメント一覧
//cand_ng_id[n].フィールド名
//user_id fwMessages[m].user_id
//date    0が入っているはず
//message fwMessages[m]._message
//vpos    fwMessages[m]._vpos これの有無でng_idsの配列と区別がつく
//no      fwMessages[m].no mと一緒ではある

//↓最大NGID保存数 これを超えるとヒットが古いのから消される
var max_ng_id = 500;
//↓NGID期限 (単位ms) 指定した期間ヒットしないと消える
var ng_id_expires = 30 * 24 * 60 * 60 * 1000;
//↑どっちも実際に消去されるのは動画読み込み時
var always_open_ngid_menu = false;//NGIDに追加した時にNGID一覧を表示する
var ngid_menu_bg_alpha = 30;//リストの背景のサムネの透過度 0で読み込まない maxで100
//↓NGIDをオフにするときに押すキーコード
//このキーを押しながらフィルターオフボタンを押すとNGIDもオフにされる
//0を指定すると、キーチェックしない(他のフィルターと同列の扱いになる)
//http://hakuhin.hp.infoseek.co.jp/main/as/key.html#CODE
//ex. ctl=17 shift=16 alt=18
var ngid_off_key_code = 17;
//IDをリストとかに表示するときに頭から何文字まで表示するか
//表示上だけで、ここの数字をいくつにしてもID処理はちゃんと全文字で行われる
var id_length = 7;

//現在表示中のリストのモード
//強調表示中は"cand_ng_id"　通常のリストは"normal"
//適宜ActionScript内で変更するので、ここはいじってはいけない
var list_mode = "normal";
//強調表示状態に入ると自動スクロール禁止になるので、
//ノーマルのリストに戻るときにもとの値に戻すためのバックアップを保存しておく場所
var auto_scroll_backup;
//強調表示中にメインバーの文字をクリックするとNGIDに登録する
var quick_ngid_mode = true;


var links = new Array();//自動リンクおよびマイリストを格納しておく
links[0] = new Array();//自動リンク
links[1] = new Array();//マイリスト1個目
links[2] = new Array();//マイリスト2個目
links[3] = new Array();//マイリスト3個目
//↓共通
//links[n][m].title　動画タイトル
//links[n][m].info　動画の説明文 自動リンク接続エラーの場合はここがundefined
//links[n][m].thumb_status サムネのローディング状況
//links[n][m].number　動画番号(sm9999とか)
//↓自動リンクのみ
//links[n][m].message リンクに反応したコメント(自動リンクのみ)
//links[n][m].user_id コメントのID(自動リンクのみ) タグに反応した場合はundefined
//↓マイリストのみ
//links[n].title　マイリストのタイトル
//links[n].info マイリストの説明文 マイリスト接続エラーの場合はここがundefined
var links_num = new Array(-1,-1);//表示中のタブ番号&サムネ番号
var max_auto_link = 50;//自動リンク数がこれを超えるとリンク作るのやめる

//サムネ読み込み用配列 bufferにいれると適当に読み込んでくれる
var buffer_ary = new Array();
var loading_ary = new Array();
//フィールド名
//list_num 番号 何個目のリストか 0自動リンク 1～マイリスト
//thumb_num 番号 サムネの番号
//url 取得するサムネURL
//timeout 0
//retry 0
//status

//タグの文字列をJavaScriptに抜き出させてvideo_tagsに入れてもらう
var video_tags = new Array();
//うｐ主のマイリストをJavaScriptに（略
var my_lists = new Array();
//タイトル
var video_title = "";

//↓↓↓↓↓↓バージョン情報↓↓↓↓↓↓
var version = "flvplayer_wrapper20071010版";

//↓↓↓↓↓↓以下実験とかデバッグっぽい用↓↓↓↓↓↓

//↓↓↓↓↓↓テストモード　いろいろ↓↓↓↓↓↓
var test_mode = false;

//↓↓↓↓↓↓コメント自動収集実験用↓↓↓↓↓↓
var auto_comment_post = false;
var auto_comment_status = "ready";//"ready" "connecting"
var comment_server = "http://localhost/cgi-bin/nico-comment.cgi";//POST先のCGI
var local_last_no = 0;//ローカルに保存されてる最後のコメント番号
var local_total_count = 0;//ローカル保存されてるコメントのトータル数
var total_add_count = 0;//動画読み込んでから何件追加保存したか

//↓↓↓↓↓↓完全ローカル再生実験用 ↓↓↓↓↓↓
var local_from = "random";//保存コメントの何番目から読み込むか
//コメントが1000件保存されていて、max_commentsが500の場合
//local_from=1 1～500
//local_from=-50 451～950
//local_from=0 501～1000
//local_from="random" 適当に500件読み込む
var max_comments = 250;//最大読み込みコメント数 あとで動画の長さから決定するのでこの数字いじっても意味はない
var limit_comments=1000;//数千とか重すぎるので max_commentsがこれを超えるとこっち採用
var playLocalXML_TimerID;

//↓↓↓↓↓↓設定の初期設定とか flash側の設定が見つからない時用↓↓↓↓↓↓
var auto_repeat = false;
var end_time_ary = new Array();
var end_time = 0;
var auto_repeat_status = "ready";//ready,start
var check_repeat_threshold = 1.5;//残り1.5秒を切ると、タイマー起動
var auto_link = false;
var add_id = false;
var show_info = false;
var copy_to_clip_board = false;
var local_server = false;
var local_server_name = new Array();
local_server_name[0] = "";
var local_server_index = new Array();
local_server_index[0] = "";
var repeat_timerID;
var mouse_wheel = false;
var mouse_reverse = false;
var mouse_forward = 10;
var mouse_backward = 15;
var auto_play = true;
var always_back_to_normal_mode = false;
var change_title = false;
var use_javascript = true;
var wide_seek_bar = true;
var auto_comment_get = true;
var filter1_on = false;
var filter1_name = "上";
var filter1_commands = "place=ue";
var filter2_on = false;
var filter2_name = "下";
var filter2_commands = "place=shita";
var filter3_on = false;
var filter3_name = "大";
var filter3_commands = "size=big";
var filter4_on = false;
var filter4_name = "色";
var filter4_commands = "color=all";
var filter5_on = true;//設定にはないけどNGIDフィルター




//↓↓↓↓↓↓設定の読み込み ↓↓↓↓↓↓
var local_server_so = SharedObject.getLocal("local_server");
if(local_server_so.data.flag != undefined){local_server = Boolean(local_server_so.data.flag);}
if(local_server_so.data.name != undefined){local_server_name[0] = local_server_so.data.name;}
if(local_server_so.data.index != undefined){local_server_index[0] = local_server_so.data.index;}

var check_flv_status = "wait";//"wait" "ready" "connecting"ローカルflv検索の状況
var local_server_num = 0;
//↓ローカルサーバーを複数設定できる
//flvが大量にたまってきて、管理のために複数ディレクトリに分けたりする人向け
//配列local_server_name(flashの設定の一行目)とlocal_server_index(２行目)に
//local_server_name.push("http://localhost/flv/imas/")
//local_server_index.push("http://localhost/flv/imas/")
//とかしてやればいい
//配列の0番目がflash側で設定する項目
//サブディレクトリ全部勝手に検索とかしたかったが、いろいろめんどうで断念
//↓サンプル
//増えてくるとflvチェックに時間かかるし、なんかいい方法ないものか
//local_server_name.push("http://localhost/niconico/flv/bookmark/saizyotobuta/");
//local_server_index.push("http://localhost/niconico/flv/bookmark/saizyotobuta/");
//local_server_name.push("http://localhost/niconico/flv/bookmark/tennnennmusumetobuta/");
//local_server_index.push("http://localhost/niconico/flv/bookmark/tennnennmusumetobuta/");
//local_server_name.push("http://localhost/niconico/flv/bookmark/setonohanayome/");
//local_server_index.push("http://localhost/niconico/flv/bookmark/setonohanayome/");
//local_server_name.push("http://localhost/niconico/flv/bookmark/potemayo/");
//local_server_index.push("http://localhost/niconico/flv/bookmark/potemayo/");
//local_server_name.push("http://localhost/niconico/flv/bookmark/tukunechan/");
//local_server_index.push("http://localhost/niconico/flv/bookmark/tukunechan/");
//local_server_name.push("http://localhost/niconico/flv/bookmark/bio4/");
//local_server_index.push("http://localhost/niconico/flv/bookmark/bio4/");
//local_server_name.push("http://localhost/niconico/flv/imas_sozai/");
//local_server_index.push("http://localhost/niconico/flv/imas_sozai/");
//local_server_name.push("http://localhost/niconico/flv/upload/");
//local_server_index.push("http://localhost/niconico/flv/upload/");

var add_id_so = SharedObject.getLocal("add_id");
if(add_id_so.data.flag != undefined){add_id = Boolean(add_id_so.data.flag);}

var show_info_so = SharedObject.getLocal("show_info");
if(show_info_so.data.flag != undefined){show_info = Boolean(show_info_so.data.flag);}

var copy_to_clip_board_so = SharedObject.getLocal("copy_to_clip_board");
if(copy_to_clip_board_so.data.flag != undefined){copy_to_clip_board = Boolean(copy_to_clip_board_so.data.flag);}

var auto_repeat_so = SharedObject.getLocal("auto_repeat");
if(auto_repeat_so.data.flag != undefined){auto_repeat = Boolean(auto_repeat_so.data.flag);}
if(auto_repeat_so.data.end_time_ary != undefined){end_time_ary = auto_repeat_so.data.end_time_ary;}
for(var i=0; i<end_time_ary.length; i++){
	if(end_time_ary[i].number == VIDEO){
		end_time = end_time_ary[i].time;
		break;
	}
}

var auto_link_so = SharedObject.getLocal("auto_link");
if(auto_link_so.data.flag != undefined){auto_link = Boolean(auto_link_so.data.flag);}

var ng_ids_so = SharedObject.getLocal("ng_ids");
if(ng_ids_so.data.ids != undefined){ng_ids = ng_ids_so.data.ids;}
//旧バージョンのng_idsなら適当に整形　そろそろ消す→消した
//if(ng_ids.length > 0 && ng_ids[0].user_id == undefined){
//	var new_ng_ids = new Array();
//	var myDate = new Date();
//	var now = myDate.getTime();
//	for(var i=0; i<ng_ids.length; i++){
//		new_ng_ids.push({user_id: ng_ids[i], date: now, message: "unknown"});
//	}
//	ng_ids = new_ng_ids;
//}

//旧バージョン用　user_idがnumberならstringにする　そろそろ消す
if(ng_ids.length > 0 && typeof(ng_ids[0].user_id) == "number"){
	alert_js("Number -> String");
	for(var i=0; i<ng_ids.length; i++){
		ng_ids[i].user_id = ng_ids[i].user_id.toString();
	}
}
ng_ids = deleteExpID(ng_ids,false);//期限切れ、容量オーバーを削除
ng_ids.sortOn("user_id",16);//user_id小さい順に並べなおす
ng_ids_so.data.ids = ng_ids;
ng_ids_so.flush();

var mouse_wheel_so = SharedObject.getLocal("mouse_wheel");
if(mouse_wheel_so.data.flag != undefined){mouse_wheel = Boolean(mouse_wheel_so.data.flag);}
if(mouse_wheel_so.data.reverse != undefined){mouse_reverse = Boolean(mouse_wheel_so.data.reverse);}
if(mouse_wheel_so.data.forward != undefined){mouse_forward = Number(mouse_wheel_so.data.forward);}
if(mouse_wheel_so.data.backward != undefined){mouse_backward = Number(mouse_wheel_so.data.backward);}

var auto_play_so = SharedObject.getLocal("auto_play");
if(auto_play_so.data.flag != undefined){auto_play = Boolean(auto_play_so.data.flag);}

var always_back_to_normal_mode_so = SharedObject.getLocal("always_back_to_normal_mode");
if(always_back_to_normal_mode_so.data.flag != undefined){always_back_to_normal_mode = Boolean(always_back_to_normal_mode_so.data.flag);}

var change_title_so = SharedObject.getLocal("change_title");
if(change_title_so.data.flag != undefined){change_title = Boolean(change_title_so.data.flag);}

var use_javascript_so = SharedObject.getLocal("use_javascript");
if(use_javascript_so.data.flag != undefined){use_javascript = Boolean(use_javascript_so.data.flag);}

var wide_seek_bar_so = SharedObject.getLocal("wide_seek_bar");
if(wide_seek_bar_so.data.flag != undefined){wide_seek_bar = Boolean(wide_seek_bar_so.data.flag);}

var auto_comment_get_so = SharedObject.getLocal("auto_comment_get");
if(auto_comment_get_so.data.flag != undefined){auto_comment_get = Boolean(auto_comment_get_so.data.flag);}

var filter_so = SharedObject.getLocal("filter");
var filter_command_ary = new Array();
loadCustomFilter();
//↓あとでボタンから呼び出すかもしれないので、これだけfunction
function loadCustomFilter(){
	if(filter_so.data.filter1_flag != undefined){
		filter1_on = Boolean(filter_so.data.filter1_flag);
	}
	if(filter_so.data.filter2_flag != undefined){
		filter2_on = Boolean(filter_so.data.filter2_flag);
	}
	if(filter_so.data.filter3_flag != undefined){
		filter3_on = Boolean(filter_so.data.filter3_flag);
	}
	if(filter_so.data.filter4_flag != undefined){
		filter4_on = Boolean(filter_so.data.filter4_flag);
	}

	if(filter_so.data.filter1_commands != undefined){filter1_commands = filter_so.data.filter1_commands;}
	if(filter_so.data.filter1_name != undefined){filter1_name = filter_so.data.filter1_name;}
	if(filter_so.data.filter2_commands != undefined){filter2_commands = filter_so.data.filter2_commands;}
	if(filter_so.data.filter2_name != undefined){filter2_name = filter_so.data.filter2_name;}
	if(filter_so.data.filter3_commands != undefined){filter3_commands = filter_so.data.filter3_commands;}
	if(filter_so.data.filter3_name != undefined){filter3_name = filter_so.data.filter3_name;}
	if(filter_so.data.filter4_commands != undefined){filter4_commands = filter_so.data.filter4_commands;}
	if(filter_so.data.filter4_name != undefined){filter4_name = filter_so.data.filter4_name;}

	for(var i=1; i<=4; i++){
		filter_command_ary[i] = parseCommand(_root["filter" + i + "_commands"]);
		var btn = main_bar["filter" + i];
		if(btn != undefined){
			btn.name.text = _root["filter" + i + "_name"];
			btn.name.setTextFormat(white12b_fmt);
			btn.name._x = 0 - btn.name._width / 2;
			if(_root["filter" + i + "_on"]){
				btn._alpha = 40;
			}else{
				btn._alpha = 100;
			}
		}
		_root["filter" + i + "_flag"] = new Array();
		_root["filter" + i + "_count"] = 0;
	}
}

//↓↓↓↓↓↓ちょっと間隔を置く処理とか用↓↓↓↓↓↓
var check_interval = 599;//定期処理するためのタイマーみたいなの
//var mouse_wheel_interval;//マウスホイールが連続で行われたかどうかのチェック

//↓↓↓↓↓↓flvplayer実行前のチェック↓↓↓↓↓↓
//通常 or ローカルFLV or 完全ローカルモード
var local_file_found = false;//ローカルFLVがあるかどうか
var getflv_status = "ready";//"ready" "wait" "done"

if(wv != undefined){//完全ローカルモード
	auto_comment_post = false;
	getflv_status = "wait";
	countLocalXML(VIDEO);//保存済みコメントのラスト番号を調べにいく
}else if(local_server == true && local_server_name.length != 0 && local_server_index.length != 0){
	check_flv_status = "ready";
	getflv_status = "wait";//getflv止めとく
	//あとはtimeLine.check_flvで勝手に調べてくれる
}

//↓↓↓↓↓↓flvplayer呼び出し↓↓↓↓↓↓
createEmptyMovieClip("nico", 1);
nico.loadMovie("http://res.nicovideo.jp/flvplayer.swf?ts=" + ts);
nico._lockroot = true;


//flvplayerの位置調整
var fwOffsetY = -60;
nico._y += fwOffsetY;

function createSquareBtn(path,obj_name,label,text_fmt,w,h,depth,x,y,color){
	//path 場所 obj_name 名前 labelボタンにつける文字 text_fmtその文字のtextFormat
	//w,h ボタンのwidth height
	//depth ボタンの深度
	//x,y ボタン中央のx,y座標
	//color 色 16進数 0xffffff
	//path=path obj_name="name"にすると
	//path.btnを指定色で四角に描画して、path.btn.lableをボタン中央に配置する
	var btn = path.createEmptyMovieClip(obj_name, depth);
	createSquare(btn,x,y,w,h,color);
//	if(label != ""){
		btn.createTextField("name",1,0,0,1,1);
		btn.name.type = "dynamic";
		btn.name.border = false;
		btn.name.selectable = false;
		btn.name.background = false;
		btn.name.autoSize = true;
		btn.tabEnabled = false;
		btn.name.text = label;
		btn.name.setTextFormat(text_fmt);
		btn.name._x = 0 - btn.name._width / 2;
		btn.name._y = 0 - btn.name._height / 2;
//	}
	btn.onRollOver = function(){
		this._alpha = 60;
	};
	btn.onRollOut = function(){
		this._alpha = 100;
	};
	btn.onReleaseOutside = btn.onRollOut;
}
function createSquare(path,x,y,w,h,color){
	//角がちょっと丸い四角をpathに描画する
	//x,y四角の中央の座標 w,h幅高さ color色
	path._x = x;
	path._y = y;
	w = Math.floor(w/2) * 2;
	h = Math.floor(h/2) * 2;
	path.beginFill(color,100);
	path.moveTo(-w/2+4,h/2);
	path.lineTo(w/2-4,h/2);
	path.curveTo(w/2,h/2,w/2,h/2-4);
	path.lineTo(w/2,-h/2+4);
	path.curveTo(w/2,-h/2,w/2-4,-h/2);
	path.lineTo(-w/2+4,-h/2);
	path.curveTo(-w/2,-h/2,-w/2,-h/2+4);
	path.lineTo(-w/2,h/2-4);
	path.curveTo(-w/2,h/2,-w/2+4,h/2);
	path.endFill();
}
function createToggleBtn(path,obj_name,label,text_fmt,depth,x,y,color){
	//トグルボタン(オンオフ切り替えボタン)
	//path パス obj_name 名前 labelボタンの横のラベル文字 text_fmtその文字のtextFormat
	//depth ボタン深度
	//x,y　ボタンの中央のx,y座標
	//color onボタンの色 16進数 0xffffffとか
	//path=path obj_name="name"にすると
	//path.name.on path.name.off path.name.labelの3つを作成する
	//オンオフ切り替えで_root.nameをtrue or falseに変更するボタン
	//name_so.data.flagにそのbooleanを書き込む
	//別のアクションを行う場合はあとでonReleaseを上書きすること
	var btn = path.createEmptyMovieClip(obj_name,depth);
	btn._x = x;
	btn._y = y;
	var btn_off = btn.createEmptyMovieClip("off", 1);
	var w = 14;//ボタンのサイズ
	btn_off.lineStyle(1,color,100);
	btn_off.beginFill(0xF0F0F0,100);
	btn_off.moveTo(-w/2,w/2);
	btn_off.lineTo(w/2,w/2);
	btn_off.lineTo(w/2,-w/2);
	btn_off.lineTo(-w/2,-w/2);
	btn_off.lineTo(-w/2,w/2);
	btn_off.endFill();

	duplicateMovieClip(btn_off,"on",2);
	var btn_on = btn.on;
	var w2 = w - 4;
	btn_on.beginFill(color,100);
	btn_on.moveTo(-w2/2,w2/2);
	btn_on.lineTo(w2/2,w2/2);
	btn_on.lineTo(w2/2,-w2/2);
	btn_on.lineTo(-w2/2,-w2/2);
	btn_on.lineTo(-w2/2,w2/2);
	btn_on.endFill();

	btn.createTextField("label",3,0,0,1,1);
	var btn_tf = btn.label;
	btn_tf.type = "dynamic";
	btn_tf.border = false;
	btn_tf.background = false;
	btn_tf.selectable = false;
	btn_tf.autoSize = true;
	btn_tf.text = label;
	btn_tf.setTextFormat(text_fmt);
	btn_tf._x = w/2 + 2;
	btn_tf._y = - btn_tf._height/2;

	btn_on.onRelease = function(){
		btn_on._visible = false;
		_root[obj_name] = false;
		var so = _root[obj_name + "_so"];
		so.data.flag = false;
		so.flush();
	};
	btn_off.onRelease = function(){
		btn_on._visible = true;
		_root[obj_name] = true;
		var so = _root[obj_name + "_so"];
		so.data.flag = true;
		so.flush();
	};

	btn_off.onRollOver = function(){
		this._alpha = 60;
	};
	btn_off.onRollOut = function(){
		this._alpha = 100;
	};
	btn_off.onReleaseOutside = btn_off.onRollOut;
	btn_on.onRollOver = function(){
		this._alpha = 60;
	};
	btn_on.onRollOut = function(){
		this._alpha = 100;
	};
	btn_on.onReleaseOutside = btn_on.onRollOut;
}

var black12_fmt = new TextFormat();
black12_fmt.font = "Arial";
black12_fmt.size = 12;
black12_fmt.bold = false;
black12_fmt.color = 0x000000;
black12_fmt.align = "left";
black12_fmt.rightMargin = 1;
black12_fmt.leftMargin = 1;

var black12b_fmt = new TextFormat();
black12b_fmt.font = "Arial";
black12b_fmt.size = 12;
black12b_fmt.bold = true;
black12b_fmt.color = 0x000000;
black12b_fmt.align = "left";
black12b_fmt.rightMargin = 1;
black12b_fmt.leftMargin = 1;

var black14b_fmt = new TextFormat();
black14b_fmt.font = "Arial";
black14b_fmt.size = 14;
black14b_fmt.bold = true;
black14b_fmt.color = 0x000000;
black14b_fmt.align = "left";
black14b_fmt.rightMargin = 1;
black14b_fmt.leftMargin = 1;

var red14b_fmt = new TextFormat();
red14b_fmt.font = "Arial";
red14b_fmt.size = 14;
red14b_fmt.bold = true;
red14b_fmt.color = 0xFF0000;
red14b_fmt.align = "left";
red14b_fmt.rightMargin = 1;
red14b_fmt.leftMargin = 1;

var white14b_fmt = new TextFormat();
white14b_fmt.font = "Arial";
white14b_fmt.size = 14;
white14b_fmt.bold = true;
white14b_fmt.color = 0xffffff;
white14b_fmt.align = "left";
white14b_fmt.rightMargin = 1;
white14b_fmt.leftMargin = 1;

var black10_fmt = new TextFormat();
black10_fmt.font = "Arial";
black10_fmt.size = 10;
black10_fmt.bold = false;
black10_fmt.color = 0x000000;
black10_fmt.align = "left";
black10_fmt.rightMargin = 1;
black10_fmt.leftMargin = 1;

var black11_fmt = new TextFormat();
black11_fmt.font = "Arial";
black11_fmt.size = 11;
black11_fmt.bold = false;
black11_fmt.color = 0x000000;
black11_fmt.align = "left";
black11_fmt.rightMargin = 1;
black11_fmt.leftMargin = 1;

var white12b_fmt = new TextFormat();
white12b_fmt.font = "Arial";
white12b_fmt.size = 12;
white12b_fmt.bold = true;
white12b_fmt.color = 0xFFFFFF;
white12b_fmt.align = "left";
white12b_fmt.rightMargin = 1;
white12b_fmt.leftMargin = 1;

var white10_fmt = new TextFormat();
white10_fmt.font = "Arial";
white10_fmt.size = 10;
white10_fmt.bold = false;
white10_fmt.color = 0xFFFFFF;
white10_fmt.align = "left";
white10_fmt.rightMargin = 1;
white10_fmt.leftMargin = 1;

var red10_fmt = new TextFormat();
red10_fmt.font = "Arial";
red10_fmt.size = 10;
red10_fmt.bold = false;
red10_fmt.color = 0xFF0000;
red10_fmt.align = "left";
red10_fmt.rightMargin = 1;
red10_fmt.leftMargin = 1;

var red24b_fmt = new TextFormat();
red24b_fmt.font = "Arial";
red24b_fmt.size = 24;
red24b_fmt.bold = true;
red24b_fmt.color = 0xE02020;
red24b_fmt.align = "left";
red24b_fmt.rightMargin = 1;
red24b_fmt.leftMargin = 1;

//★★★★★★★★★★★上のバー 2★★★★★★★★★★★
main_bar.swapDepths(2);
main_bar.base.swapDepths(1);
main_bar.base.onRelease = function(){
	if(quick_ngid_mode && loglist_menu.add_id._visible){
		var xm = main_bar._xmouse;
		if(xm > main_bar.main_info._x && xm < main_bar.main_info._x + main_bar.main_info._width){
			var ym = main_bar._ymouse;
			if(ym > main_bar.main_info._y && ym < main_bar.main_info._y + main_bar.main_info._height){
				loglist_menu.add_id._visible = false;
				cand_ng_id = deleteRepField(cand_ng_id,"user_id",false);
				updateFilter("add_id");
			}
		}
	}
};

main_bar.icon_local.swapDepths(2);
main_bar.icon_local._visible=false;

//フィルター情報表示テキストフィールド 3-6
main_bar.createEmptyMovieClip("auto_comment_get_icon",3);
createSquare(main_bar.auto_comment_get_icon,163,20,36,28,0x909090);
//createSquareBtn(main_bar,"auto_comment_get_icon","",white10_fmt,40,10,3,163,20+21,0x505050);
main_bar.auto_comment_get_icon._alpha = 0;
main_bar.auto_comment_get_icon.onRollOver = function(){
	this._alpha = 60;
};
main_bar.auto_comment_get_icon.onRollOut = function(){
	this._alpha = 0;
};
main_bar.auto_comment_get_icon.onRelease = function(){
	auto_comment_get = !auto_comment_get;
	showFilterInfo(main_bar.filter_info1.text,main_bar.filter_info2.text);
	if(auto_comment_get){
		clearInterval(nico.ThreadIntervalID);
		var interval = nico.HTTP_INTERVAL_SHORT_ECONOMY;
		if (nico.PremiumFlag == 1) {
			interval = nico.HTTP_INTERVAL_SHORT;
		}
		nico.ThreadIntervalID = setInterval(nico.onThreadInterval, interval);
		nico.ThreadIntervalShort = true;
		auto_comment_get_so.data.flag = true;
	}else{
		auto_comment_get_so.data.flag = false;
	}
	auto_comment_get_so.flush();
};
main_bar.auto_comment_get_icon.onReleaseOutside = main_bar.auto_comment_get_icon.onRollOut;
main_bar.createTextField("filter_info1",4,115,2,1,1);
main_bar.filter_info1.type = "dynamic";
main_bar.filter_info1.border = false;
main_bar.filter_info1.selectable = false;
main_bar.filter_info1.background = false;
main_bar.filter_info1.autoSize = true;
main_bar.createTextField("filter_info2",5,115,16,1,1);
main_bar.filter_info2.type = "dynamic";
main_bar.filter_info2.selectable = false;
main_bar.filter_info2.border = false;
main_bar.filter_info2.background = false;
main_bar.filter_info2.autoSize = true;
main_bar.createEmptyMovieClip("filter_info_line",6);
showFilterInfo(0,0);
function showFilterInfo(num1,num2){
	if(auto_comment_get){
		var fmt = black14b_fmt;
	}else{
		var fmt = red14b_fmt;
	}
	main_bar.filter_info1.text = num1;
	main_bar.filter_info1.setTextFormat(fmt);
	main_bar.filter_info1._x = 160 - main_bar.filter_info1.textWidth / 2;
	main_bar.filter_info2.text = num2;
	main_bar.filter_info2.setTextFormat(fmt);
	main_bar.filter_info2._x = 160 - main_bar.filter_info2.textWidth / 2;
	drawFilterInfoLine(fmt.color);
}
function drawFilterInfoLine(color){
	if(main_bar.filter_info_line != undefined){
		main_bar.filter_info_line.removeMovieClip();//一応消しとく
	}
	main_bar.createEmptyMovieClip("filter_info_line",6);
	main_bar.filter_info_line.lineStyle(2,color,100);
	main_bar.filter_info_line.moveTo(-15,0);
	main_bar.filter_info_line.lineTo(15,0);
	main_bar.filter_info_line._x = 163;
	main_bar.filter_info_line._y = 19;
}


//メイン情報表示テキストフィールド 7
main_bar.createTextField("main_info",7,210,10,240,20);
main_bar.main_info.type = "dynamic";
main_bar.main_info.border = false;
main_bar.main_info.selectable = false;
main_bar.main_info.background = false;
main_bar.main_info.autoSize = true;

main_bar.main_info.background = false;
main_bar.main_info.setTextFormat(black12_fmt);
//自動コメント収集アイコン 8-9
createSquareBtn(main_bar,"auto_comment_icon","C",white12b_fmt,16,16,8,720,19,0x303030);
if(!auto_comment_post){main_bar.auto_comment_icon._visible = false;}
main_bar.auto_comment_icon.onRelease = function(){
	if(auto_comment_status == "ready" && wv == undefined){
		sendLocalXML();
	}
};

//フィルター1 11
createSquareBtn(main_bar,"filter1",filter1_name.charAt(0),white12b_fmt,20,28,11,20,20,0x303030);
main_bar.filter1.name._y += 4;
if(filter1_on){
	main_bar.filter1._alpha = 40;
}else{
	main_bar.filter1._alpha = 100;
}
main_bar.filter1.createTextField("count",2,0,0,1,1);
main_bar.filter1.count.type = "dynamic";
main_bar.filter1.count.border = false;
main_bar.filter1.count.background = false;
main_bar.filter1.count.selectable = false;
main_bar.filter1.count.autoSize = true;
main_bar.filter1.count.text = 0;
main_bar.filter1.count.setTextFormat(white10_fmt);
main_bar.filter1.count._x = 0 - main_bar.filter1.count._width / 2;
main_bar.filter1.count._y = -17;
main_bar.filter1.onRelease = function(){
	if(!filter1_on){
		updateFilter("add_filter",1);
		this._alpha = 40;
	}
};
main_bar.filter1.onRollOver = function(){
	if(!filter1_on){
		this._alpha = 60;
	}
};
main_bar.filter1.onRollOut = function(){
	if(!filter1_on){
		this._alpha = 100;
	}
};
main_bar.filter1.onReleaseOutside = main_bar.filter1.onRollOut;

//フィルター2 14
createSquareBtn(main_bar,"filter2",filter2_name.charAt(0),white12b_fmt,20,28,14,42,20,0x303030);
main_bar.filter2.name._y += 4;
if(filter2_on){
	main_bar.filter2._alpha = 40;
}else{
	main_bar.filter2._alpha = 100;
}
main_bar.filter2.createTextField("count",2,0,0,1,1);
main_bar.filter2.count.type = "dynamic";
main_bar.filter2.count.border = false;
main_bar.filter2.count.background = false;
main_bar.filter2.count.selectable = false;
main_bar.filter2.count.autoSize = true;
main_bar.filter2.count.text = 0;
main_bar.filter2.count.setTextFormat(white10_fmt);
main_bar.filter2.count._x = 0 - main_bar.filter2.count._width / 2;
main_bar.filter2.count._y = -17;
main_bar.filter2.onRelease = function(){
	if(!filter2_on){
		updateFilter("add_filter",2);
		this._alpha = 40;
	}
};
main_bar.filter2.onRollOver = function(){
	if(!filter2_on){
		this._alpha = 60;
	}
};
main_bar.filter2.onRollOut = function(){
	if(!filter2_on){
		this._alpha = 100;
	}
};
main_bar.filter2.onReleaseOutside = main_bar.filter2.onRollOut;

//フィルター3 17
createSquareBtn(main_bar,"filter3",filter3_name.charAt(0),white12b_fmt,20,28,17,64,20,0x303030);
main_bar.filter3.name._y += 4;
if(filter3_on){
	main_bar.filter3._alpha = 40;
}else{
	main_bar.filter3._alpha = 100;
}
main_bar.filter3.createTextField("count",2,0,0,1,1);
main_bar.filter3.count.type = "dynamic";
main_bar.filter3.count.border = false;
main_bar.filter3.count.background = false;
main_bar.filter3.count.selectable = false;
main_bar.filter3.count.autoSize = true;
main_bar.filter3.count.text = 0;
main_bar.filter3.count.setTextFormat(white10_fmt);
main_bar.filter3.count._x = 0 - main_bar.filter3.count._width / 2;
main_bar.filter3.count._y = -17;
main_bar.filter3.onRelease = function(){
	if(!filter3_on){
		updateFilter("add_filter",3);
		this._alpha = 40;
	}
};
main_bar.filter3.onRollOver = function(){
	if(!filter3_on){
		this._alpha = 60;
	}
};
main_bar.filter3.onRollOut = function(){
	if(!filter3_on){
		this._alpha = 100;
	}
};
main_bar.filter3.onReleaseOutside = main_bar.filter3.onRollOut;

//フィルター4 20
createSquareBtn(main_bar,"filter4",filter4_name.charAt(0),white12b_fmt,20,28,20,86,20,0x303030);
main_bar.filter4.name._y += 4;
if(filter4_on){
	main_bar.filter4._alpha = 40;
}else{
	main_bar.filter4._alpha = 100;
}
main_bar.filter4.createTextField("count",2,0,0,1,1);
main_bar.filter4.count.type = "dynamic";
main_bar.filter4.count.border = false;
main_bar.filter4.count.background = false;
main_bar.filter4.count.selectable = false;
main_bar.filter4.count.autoSize = true;
main_bar.filter4.count.text = 0;
main_bar.filter4.count.setTextFormat(white10_fmt);
main_bar.filter4.count._x = 0 - main_bar.filter4.count._width / 2;
main_bar.filter4.count._y = -17;
main_bar.filter4.onRelease = function(){
	if(!filter4_on){
		updateFilter("add_filter",4);
		this._alpha = 40;
	}
};
main_bar.filter4.onRollOver = function(){
	if(!filter4_on){
		this._alpha = 60;
	}
};
main_bar.filter4.onRollOut = function(){
	if(!filter4_on){
		this._alpha = 100;
	}
};
main_bar.filter4.onReleaseOutside = main_bar.filter4.onRollOut;

//filter5(NGID) 23
createSquareBtn(main_bar,"filter5","ID",white12b_fmt,20,28,23,108,20,0x303030);
main_bar.filter5.name._y += 4;
if(filter5_on){
	main_bar.filter5._alpha = 40;
}else{
	main_bar.filter5._alpha = 100;
}
main_bar.filter5.createTextField("count",25,0,0,1,1);
main_bar.filter5.count.type = "dynamic";
main_bar.filter5.count.border = false;
main_bar.filter5.count.background = false;
main_bar.filter5.count.selectable = false;
main_bar.filter5.count.autoSize = true;
main_bar.filter5.count.text = 0;
main_bar.filter5.count.setTextFormat(white10_fmt);
main_bar.filter5.count._x = 0 - main_bar.filter5.count._width / 2;
main_bar.filter5.count._y = -17;
main_bar.filter5.onRelease = function(){
	if(!filter5_on){
		updateFilter("add_filter",5);
		this._alpha = 40;
	}
};
main_bar.filter5.onRollOver = function(){
	if(!filter5_on){
		this._alpha = 60;
	}
};
main_bar.filter5.onRollOut = function(){
	if(!filter5_on){
		this._alpha = 100;
	}
};
main_bar.filter5.onReleaseOutside = main_bar.filter5.onRollOut;

//フィルター解除 26
createSquareBtn(main_bar,"filter_off","",undefined,20,20,26,130,24,0x303030);
main_bar.filter_off.lineStyle(2,0xFFFFFF,100);
main_bar.filter_off.moveTo(10-3,10-3);
main_bar.filter_off.lineTo(-10+3,-10+3);
main_bar.filter_off.moveTo(-10+3,10-3);
main_bar.filter_off.lineTo(10-3,-10+3);
main_bar.filter_off.onRelease = function(){
	var key_flag;
	if(ngid_off_key_code == 0){key_flag = true;}
	else{key_flag = Key.isDown(ngid_off_key_code);}
	if(filter1_on || filter2_on || filter3_on || filter4_on || (filter5_on && key_flag)){
		main_bar.filter1._alpha = 100;
		main_bar.filter2._alpha = 100;
		main_bar.filter3._alpha = 100;
		main_bar.filter4._alpha = 100;
		if(key_flag){main_bar.filter5._alpha = 100;}
		updateFilter("clear_filter");
	}
};

//ダウンロード 35
createSquareBtn(main_bar,"download","DL",white12b_fmt,30,24,35,422,20,0x303030);
main_bar.download.onRelease = function(){
	downloadFLV();
	this._alpha = 40;
};

//設定メニュー 37
createSquareBtn(main_bar,"pref_menu","設定",white12b_fmt,40,24,37,459,20,0x303030);
main_bar.pref_menu.onRelease = function(){
	if(pref_menu._visible){
		closePrefMenu();
	}else{
		openPrefMenu();
		goTopDepth(pref_menu);
	}
	this._alpha = 40;
};

//NGID詳細 33
createSquareBtn(main_bar,"ngid_view","NGID一覧",white12b_fmt,60,24,33,511,20,0x303030);
main_bar.ngid_view.onRelease = function(){
	if(ngid_menu._visible){
		updateNGIDMenu("close");
	}else{
		updateNGIDMenu("ng_ids");
		goTopDepth(ngid_menu);
	}
	this._alpha = 40;
};

//リンクボタン 40
createSquareBtn(main_bar,"link","LINK",white12b_fmt,40,24,40,570,20,0x303030);
main_bar.link._visible = false;
main_bar.link.onRelease = function(){
	this._visible = false;
	link_thumb._visible = true;
	goTopDepth(link_thumb);
};

//自動コメント収集情報 50
main_bar.createTextField("auto_comment_info1",50,621,3,1,1);
main_bar.auto_comment_info1.type = "dynamic";
main_bar.auto_comment_info1.border = false;
main_bar.auto_comment_info1.selectable = false;
main_bar.auto_comment_info1.background = false;
main_bar.auto_comment_info1.autoSize = true;
main_bar.auto_comment_info1.setTextFormat(black14b_fmt);
main_bar.createTextField("auto_comment_info2",51,621,17,1,1);
main_bar.auto_comment_info2.type = "dynamic";
main_bar.auto_comment_info2.border = false;
main_bar.auto_comment_info2.selectable = false;
main_bar.auto_comment_info2.background = false;
main_bar.auto_comment_info2.autoSize = true;
main_bar.auto_comment_info2.setTextFormat(black14b_fmt);
main_bar.auto_comment_info2._x = 300 - main_bar.auto_comment_info2.textWidth / 2;
main_bar.createEmptyMovieClip("auto_comment_info_line",52);
main_bar.auto_comment_info_line.lineStyle(2,0x000000,100);
main_bar.auto_comment_info_line.moveTo(-18,0);
main_bar.auto_comment_info_line.lineTo(18,0);
main_bar.auto_comment_info_line._x = 685;
main_bar.auto_comment_info_line._y = 20;
main_bar.auto_comment_info_line._visible = false;

//★★★★★★★★★★★スクリーン 100～★★★★★★★★★★★
screen.swapDepths(100);
//スクリーン情報テキストフィールド
screen.createTextField("wrapper_info",101,0,15,1,1);
screen.wrapper_info.type = "dynamic";
screen.wrapper_info.border = false;
screen.wrapper_info.background = false;
screen.wrapper_info.autoSize = true;
screen.wrapper_info.selectable = false;
screen.wrapper_info._visible = false;
screen.wrapper_info.setTextFormat(red24b_fmt);

screen.createTextField("auto_play_info",102,1,1,1,1);
screen.auto_play_info.type = "dynamic";
screen.auto_play_info.border = false;
screen.auto_play_info.background = true;
screen.auto_play_info.autoSize = true;
screen.auto_play_info.selectable = false;
screen.auto_play_info._visible = false;
screen.auto_play_info.text = "画面クリックまたはホイールシークで再生開始";
screen.auto_play_info.setTextFormat(red24b_fmt);
screen.auto_play_info._x = 270-screen.auto_play_info.textWidth/2;
screen.auto_play_info._y = 180;

//スクリーンのマウスの下に位置しているコメントのIDを探す
function searchID(){
	var result_id = -1;
	var xm = nico.videowindow._xmouse;
	var ym = nico.videowindow._ymouse;
	var Slot = nico.MessageSlots;

	for(var i=0; i < Slot.length; i++){//どのMessageSlotsをクリックしたのか調べるiループ
		if(Slot[i]._text.text != ""){
			var x = Slot[i]._text._x;
			var y = Slot[i]._text._y;
			var w = Slot[i]._text._width;
			var h = Slot[i]._text._height;
			if( x < xm && x+w > xm && y < ym && y+h > ym){//どのMessageSlotsか分かった
				var result_num = binarySearch(fwMessages,"_no",Slot[i]._message._no);
				result_id = fwMessages[result_num].user_id;
				break;
			}
		}
	}
	return result_id;
}

//指定IDを強調表示する
//idにマイナス渡すと全解除
function emphID(id){
	var Slot = nico.MessageSlots;
	var Mes = nico.Messages;

	cand_ng_id = new Array();//リセット
	//とりあえずSlotsの枠を全部はずす
	clearEmphMes("MessageSlots");

	if(id < 0){//idがない場合は全解除
		showInfoOnMainBar("強調表示機能は解除中です");
		if(list_mode != "normal"){updateLogList("clear");}
		clearEmphMes("Messages");
	}else{
		for(var i=0; i<fwMessages.length; i++){
			if(fwMessages[i].user_id != id){//同一ID以外のコメントなら
				Mes[i]._mine = false;//Messagesの枠外す
			}else{//同一ID発見
				//cand_ng_idに追加していく
				cand_ng_id.push({user_id: id, date: 0, message: fwMessages[i]._message, vpos: fwMessages[i]._vpos, no:fwMessages[i].no});
				Mes[i]._mine = true;//Messagesに枠つける
				if(Mes[i]._slot != undefined){//表示中のコメントならSlotsにも枠つける
					Slot[Mes[i]._slot]._text.border = true;
					Slot[Mes[i]._slot]._text.borderColor = 16776960;
				}
			}
		}
		var name = id;
		if(id == "0"){name = "名無し";}//idなしは0として保存されている
		var comment_message = "[" + name.substr(0,id_length) + "] さんのコメント  " + cand_ng_id.length +" 件";
		if(copy_to_clip_board){
			System.setClipboard(name);
			comment_message += "(C)";
		}
		showInfoOnMainBar(comment_message);
		updateLogList("cand_ng_id");
	}
}

function clearEmphMes(mode){
	if(mode == "MessageSlots" || mode == "both"){
		var Slot = nico.MessageSlots;
		for(var i=0; i < Slot.length; i++){
			Slot[i]._text.border=false;
		}
	}
	if(mode == "Messages" || mode == "both"){
		var Mes = nico.Messages;
		for(var i=0; i < Mes.length; i++){
			Mes[i]._mine = false;
		}
	}
}

//★★★★★★★★★★★★★NGID確認メニュー(21000) ★★★★★★★★★★★★★
//自前でスクロールバーとか一式作るとどうなるんだろうかという実験
ngid_menu.swapDepths(21000);
ngid_menu._visible = false;
ngid_menu.base.onPress = function(){
	var xm = ngid_menu._xmouse;
	var ym = ngid_menu._ymouse;
	if(xm>0 && xm<369 && ym>0 && ym<25){
		ngid_menu.startDrag();
	}
	goTopDepth(ngid_menu);
};
ngid_menu.base.onRelease=function(){
	var xm = ngid_menu._xmouse;
	var ym = ngid_menu._ymouse;
	if(xm>370 && xm<395 && ym>0 && ym<25){
		updateNGIDMenu("close");
	}else{
		ngid_menu.stopDrag("");
	}
};
ngid_menu.base.onReleaseOutside = ngid_menu.base.onRelease;
if(VIDEO.substr(0,2) == "sm" && ngid_menu_bg_alpha > 0){
	ngid_menu.createEmptyMovieClip("bg",201);
	ngid_menu.bg.loadMovie("http://tn-skr.smilevideo.jp/smile?i=" + VIDEO.substr(2));
}
ngid_menu.createTextField("info",202,0,5,1,1);
ngid_menu.info.type = "dynamic";
ngid_menu.info.selectable = false;
ngid_menu.info.border = false;
ngid_menu.info.background = false;
ngid_menu.info.autoSize = true;

ngid_menu.createTextField("header",205,20,30,1,1);
ngid_menu.header.type = "dynamic";
ngid_menu.header.selectable = false;
ngid_menu.header.border = false;
ngid_menu.header.background = false;
ngid_menu.header.autoSize = true;

ngid_menu.createTextField("mes",206,10,50,380,260);
ngid_menu.mes.type = "dynamic";
ngid_menu.mes.border = true;
ngid_menu.mes.background = false;
ngid_menu.mes.autoSize = false;
ngid_menu.mes.wordWrap = false;
ngid_menu.mes.multiline = true;
ngid_menu.mes.mouseWheelEnabled = false;

//スクロールバー
ngid_menu.createEmptyMovieClip("slider_bar",209);
//			var x = ngid_menu.mes._x + ngid_menu.mes._width - 18
//			var y = ngid_menu.mes._y
ngid_menu.slider_bar._x = ngid_menu.mes._x + ngid_menu.mes._width - 18;
ngid_menu.slider_bar._y = ngid_menu.mes._y;
//			var h = ngid_menu.mes._height
ngid_menu.slider_bar.lineStyle(1,0x000000,100);
ngid_menu.slider_bar.beginFill(0xffffff,100);
ngid_menu.slider_bar.moveTo(0,0);
ngid_menu.slider_bar.lineTo(17,0);
ngid_menu.slider_bar.lineTo(17,ngid_menu.mes._height);
ngid_menu.slider_bar.lineTo(0,ngid_menu.mes._height);
ngid_menu.slider_bar.lineTo(0,0);
ngid_menu.slider_bar.endFill();
ngid_menu.slider_bar._alpha = 70;
ngid_menu.slider_bar.onPress = function (){
	var ym = this._ymouse + ngid_menu.mes._y;
	var move_value = 16;
	if(ym < ngid_menu.slider_knob._y){
		move_value = -16;
	}
	scrollNGIDMenu(move_value);
	var bar_click_interval = 0;
	var bar_scroll_interval = 0;
	this.onEnterFrame = function(){
		bar_click_interval++;
		bar_scroll_interval++;
		if(bar_click_interval > 30){
			bar_click_interval = 61;
			if(bar_scroll_interval > 2){
				scrollNGIDMenu(move_value);
				bar_scroll_interval = 0;
				var ym = this._ymouse + ngid_menu.mes._y;
				if((move_value>0 && ym < ngid_menu.slider_knob._y) || (move_value<0 && ym > ngid_menu.slider_knob._y)){
					bar_click_interval = undefined;
					bar_scroll_interval = undefined;
					delete this.onEnterFrame;
				}
			}
		}
	};
};
ngid_menu.slider_bar.onRelease = function (){
	delete this.onEnterFrame;
};
ngid_menu.slider_bar.onReleaseOutside = ngid_menu.slider_bar.onRelease;

createSquareBtn(ngid_menu,"export_id","ID Copy",white12b_fmt,80,20,211,50,325,0x303030);
ngid_menu.export_id.onRelease = function(){
	this._alpha = 40;
	var output = "";
	ng_ids.sortOn("user_id",16);
	for(var i=0; i<ng_ids.length; i++){
		output += ng_ids[i].user_id + "\n";
	}
	System.setClipboard(output);
	showInfoOnMainBar("NGIDを" + ng_ids.length + "件クリップボードにコピーしました");
};

createSquareBtn(ngid_menu,"import_id","ID Import",white12b_fmt,80,20,213,135,325,0x303030);
ngid_menu.import_id.onRelease = function(){
	updateNGIDMenu("import_id");
};

createSquareBtn(ngid_menu,"ok","OK",white12b_fmt,40,18,215,300,39,0x303030);
ngid_menu.ok.onRelease = function(){
	var mes_ary = new Array();
	mes_ary = ngid_menu.mes.text.split("\r");//nだとダメだった
	var num_ary = new Array();
	for(var i=0; i < mes_ary.length; i++){//27文字ピッタリ、もしくは数字だけのヤツを読み込む
		if(mes_ary[i].length == 27 || checkNum(mes_ary[i])){
			num_ary.push({user_id: mes_ary[i], date: 0, message: "unknown"});
		}
	}
	cand_ng_id = deleteRepField(num_ary,"user_id",false);
	updateFilter("add_id");
};

createSquareBtn(ngid_menu,"cancel","CANCEL",white12b_fmt,60,18,217,352,39,0x303030);
ngid_menu.cancel.onRelease = function(){
	updateNGIDMenu("ng_ids");
};

createSquareBtn(ngid_menu,"clear_id","全削除",white12b_fmt,70,20,203,355,325,0x303030);
ngid_menu.clear_id.onRelease = function(){
	updateFilter("clear_id");
	this._alpha = 40;
};

//NGIDメニュー
function updateNGIDMenu(mode){
	if(mode == "close"){//ウィンドウを消す
		ngid_menu._visible = false;
		ngid_menu.slider_knob.removeMovieClip();//一応消しとく
		ngid_menu.mes.text = "";
	}else{
		ngid_menu._visible = true;
		if(ngid_menu.bg != undefined && ngid_menu.bg.getBytesTotal() > 0){
			ngid_menu.bg._alpha = ngid_menu_bg_alpha;
			ngid_menu.bg._x = ngid_menu.mes._x + 1;
			ngid_menu.bg._y = ngid_menu.mes._y + 1;
			ngid_menu.bg._width = 380 - 1;
			ngid_menu.bg._height = ngid_menu.mes._height - 1;
		}
		//modeごとの処理
		if(mode == "ng_ids"){//NGID一覧
			ngid_menu.mes.text = "";
			ngid_menu.mes.type = "dynamic";
			ngid_menu.ok._visible = false;
			ngid_menu.cancel._visible = false;
			ngid_menu.export_id._visible = true;
			ngid_menu.import_id._visible = true;
			if(ng_ids.length > 0){
				ngid_menu.clear_id._visible = true;
			}else{
				ngid_menu.clear_id._visible = false;
			}
			ngid_menu.info.text = "NGID一覧";
			var ng_id_expires_day = Math.floor(ng_id_expires / (24*60*60*1000));
			if(ng_id_expires_day == 0){ ng_id_expires_day = "1日未満";}
			else{ ng_id_expires_day += "日";}
			ngid_menu.header.text = "最新ヒットリスト 全" + ng_ids.length + "件   " + "[Max:" + max_ng_id + "件] [期限:" + ng_id_expires_day + "]";
			var mess = "";
			var myDate = new Date();
			var ms, day, hour, min, sec, time;
			ng_ids.sortOn("date",16|2);//dateフィールドの数値の大きい順に並べる
			for(var i=0; i<ng_ids.length; i++){
				ms = myDate.getTime() - ng_ids[i].date;
				day = Math.floor(ms/(1000*60*60*24));
				hour =  Math.floor(ms/(1000*60*60)) - Math.floor(Math.floor(ms/(1000*60*60))/24)*24;
				min =  Math.floor(ms/(1000*60)) - Math.floor(Math.floor(ms/(1000*60))/60)*60;
				sec =  Math.floor(ms/(1000)) - Math.floor(Math.floor(ms/(1000))/60)*60;
				if(day >= 2){
					if(day<10){day = "0" + day;}
					time = day + "日前";
				}else{
					if(day == 1){
						time = (day * 24 + hour) + "時間前";
					}else if(hour > 0){
						if(hour<10){hour = "0" + hour;}
						time = hour + "時間前";
					}else if(min > 0){
						if(min<10){min = "0" + min;}
						time = min + "分前";
					}else{
						if(sec<10){sec = "0" + sec;}
						time = sec + "秒前";
					}
				}
				mess += time + " [" + ng_ids[i].user_id.substr(0,id_length) + "] " + replaceSentence(ng_ids[i].message,["\n","\r"],"") + "\n";
			}
			ngid_menu.mes.text = mess;
			ng_ids.sortOn("user_id",16);//user_idの数値の小さい順に戻しておく
			ngid_menu.info.setTextFormat(black12_fmt);
			ngid_menu.info._x = ngid_menu._width / 2 - ngid_menu.info._width / 2;
			ngid_menu.header.setTextFormat(black12_fmt);
			ngid_menu.mes.setTextFormat(black12_fmt);
			ngid_menu.mes.scroll = 0;
		}else if(mode == "import_id"){//ID Import
			ngid_menu.mes.type = "input";
			ngid_menu.mes.text = "27文字の行\nもしくは数字だけの行をNGIDとして登録します。\n";
			ngid_menu.mes.setTextFormat(black12_fmt);
			ngid_menu.info.text = "IDを読み込み";
			ngid_menu.info.setTextFormat(black12_fmt);
			ngid_menu.info._x = ngid_menu._width / 2 - ngid_menu.info._width / 2;
			ngid_menu.header.text = "ID(数字)を入力してOKボタンを押してください";
			ngid_menu.header.setTextFormat(black12_fmt);
			ngid_menu.ok._visible = true;
			ngid_menu.cancel._visible = true;
			ngid_menu.export_id._visible = false;
			ngid_menu.import_id._visible = false;
			ngid_menu.clear_id._visible = false;
		}

		//リストを作成し終わったら大きさにあわせてスライドノブ生成
		if(ngid_menu.slider_knob != undefined){
			ngid_menu.slider_knob.removeMovieClip();
		}
		if(ngid_menu.mes.textHeight < ngid_menu.mes._height){
			ngid_menu.mes._width = 380;
			ngid_menu.slider_bar._visible = false;
		}else{
			ngid_menu.mes._width = 380 - ngid_menu.slider_bar._width;
			ngid_menu.slider_bar._visible = true;
			var slider_height = ngid_menu.mes._height * ngid_menu.mes._height / ngid_menu.mes.textHeight;
			if(slider_height > ngid_menu.mes._height){slider_height = ngid_menu.mes._height;}
			if(slider_height < 30){slider_height = 30;}
			createSquareBtn(ngid_menu,"slider_knob","",undefined,ngid_menu.slider_bar._width - 1,slider_height,210,undefined,undefined,0x303030);
			ngid_menu.slider_knob._x = ngid_menu.mes._x + ngid_menu.mes._width + (ngid_menu.slider_knob._width/2);
			ngid_menu.slider_knob._y = ngid_menu.mes._y + (ngid_menu.slider_knob._height/2);
			ngid_menu.ratio = 0;
			ngid_menu.slider_knob.onPress = function(){
				this.startDrag(true, this._x, ngid_menu.mes._y + (this._height/2), this._x, ngid_menu.mes._y  + ngid_menu.mes._height - (this._height/2));
				this.onEnterFrame = function(){
					this.ratio = Math.round((this._y - (ngid_menu.mes._y+(this._height/2)))*100/(ngid_menu.mes._height - this._height));
					ngid_menu.mes.scroll = ngid_menu.mes.maxscroll * this.ratio / 100;
				};
			};
			ngid_menu.slider_knob.onRelease = function(){
				this.stopDrag();
				delete this.onEnterFrame;
			};
			ngid_menu.slider_knob.onReleaseOutside = ngid_menu.slider_knob.onRelease;
		}
	}
}

function scrollNGIDMenu(num){
	ngid_menu.mes.scroll = ngid_menu.mes.scroll + num;
	if(ngid_menu.slider_knob != undefined){
		if(ngid_menu.mes.scroll <= 1){
			ngid_menu.slider_knob._y = ngid_menu.mes._y + ngid_menu.slider_knob._height/2;
		}else if(ngid_menu.mes.scroll >= ngid_menu.mes.maxscroll){
			ngid_menu.slider_knob._y = ngid_menu.mes._y + ngid_menu.mes._height - ngid_menu.slider_knob._height/2;
		}else{
			ngid_menu.slider_knob._y = ngid_menu.mes.scroll * (ngid_menu.mes._height - ngid_menu.slider_knob._height) / ngid_menu.mes.maxscroll + ngid_menu.mes._y + ngid_menu.slider_knob._height/2;
		}
	}
}

//flvplayerのリストで表示する
function updateLogList(mode){
	if(mode == "clear"){//空欄にする
		if(list_mode != "normal"){
			if(always_back_to_normal_mode){
				updateLogList("normal");
				return;
			}else{
				nico.ClearLog();
				loglist_menu.tab._visible = true;
				loglist_menu.normal_list._visible = true;
				loglist_menu.add_id._visible = false;
				nico.tabmenu.loglist_tab._visible = false;
				nico.tabmenu.wayback_tab._visible = false;
			}
		}
	}
	if(mode == "cand_ng_id"){//強調表示中のコメント
		if(list_mode == "normal"){//ノーマルモードから強調モードに入るとき
			auto_scroll_backup = nico.tabmenu.loglist_menu.autoScroll.selected;
		}
		list_mode = "cand_ng_id";
		nico.ClearLog();
		loglist_menu.tab._visible = true;
		loglist_menu.normal_list._visible = true;
		loglist_menu.add_id._visible = true;
		nico.tabmenu.loglist_tab._visible = false;
		nico.tabmenu.wayback_tab._visible = false;
		nico.tabmenu.loglist_menu.autoScroll.selected = true;
		nico.LogList.vPosition = 0;
		cand_ng_id.sortOn("vpos",16);
		for(var i=0; i<cand_ng_id.length; i++){
			var no = cand_ng_id[i].no;
			var id = "[" + fwMessages[no].user_id.substr(0,id_length) + "] ";
			if(fwMessages[no].premium){id = "P" + id;}
			nico.AddChatLog(i, 0, fwMessages[no]._no, fwMessages[no]._vpos, id + fwMessages[no]._message, fwMessages[no].mail, "", fwMessages[no].date, 0);
		}
	}
	if(mode == "normal"){//もとの普通のリストに戻す
		if(list_mode != "normal"){
			nico.ClearLog();
			clearEmphMes("both");
			cand_ng_id = new Array();
			loglist_menu.tab._visible = false;
			loglist_menu.normal_list._visible = false;
			loglist_menu.add_id._visible = false;
			nico.tabmenu.loglist_tab._visible = true;
			nico.tabmenu.wayback_tab._visible = true;
			for(var i=0; i<fwMessages.length; i++){
				var mes = fwMessages[i]._message;
				if(add_id){//add_idならAddChatLogする前にメッセージにID付与
					if(fwMessages[i].premium){
						mes = "P[" + fwMessages[i].user_id.substr(0,id_length) + "] " + mes;
					}else{
						mes = "[" + fwMessages[i].user_id.substr(0,id_length) + "] " + mes;
					}
				}
				nico.AddChatLog(i, 0, fwMessages[i]._no, fwMessages[i]._vpos, mes, fwMessages[i].mail, "", fwMessages[i].date, 0);
			}
			list_mode = "normal";
			showInfoOnMainBar("");
			//↓自動スクロールを元の状態に戻す
			nico.tabmenu.loglist_menu.autoScroll.selected = auto_scroll_backup;
			//↓リストの一番下までスクロールさせる
			nico.LogList.vPosition = nico.LogList.length * nico.LogList.rowHeight;
		}
	}
}
//★★★★★★★★★★★★★設定メニュー(22000) ★★★★★★★★★★★★★
pref_menu.swapDepths(22000);
pref_menu._visible = false;
//pref_menu._alpha = 85;

pref_menu.base.onPress = function(){
	var xm = pref_menu._xmouse;
	var ym = pref_menu._ymouse;
	if(xm>0 && xm<325 && ym>0 && ym<25){
		pref_menu.startDrag();
	}
	goTopDepth(pref_menu);
};
pref_menu.base.onRelease=function(){
	var xm = pref_menu._xmouse;
	var ym = pref_menu._ymouse;
	if(xm>330 && xm<361 && ym>0 && ym<25){
		closePrefMenu();
	}else{
		pref_menu.stopDrag();
	}
};
//まずtoggleボタンつくる
createToggleBtn(pref_menu,"auto_link","自動リンク",black12_fmt,1,17,42,0x808080);
pref_menu.auto_link.on.onRelease = function(){
	this._visible = false;
	auto_link = false;
	auto_link_so.data.flag = false;
	auto_link_so.flush();
};
pref_menu.auto_link.off.onRelease = function(){
	this._parent.on._visible = true;
	auto_link = true;
	setAutoLinkInterval();
	auto_link_so.data.flag = true;
	auto_link_so.flush();
};
createToggleBtn(pref_menu,"auto_repeat","リピート再生",black12_fmt,2,117,42,0x808080);
pref_menu.auto_repeat.on.onRelease = function(){
	this._visible = false;
	pref_menu.end_time._visible = false;
	auto_repeat = false;
	auto_repeat_status = "ready";
	clearInterval(repeat_timerID);
	auto_repeat_so.data.flag = false;
	auto_repeat_so.flush();
};
pref_menu.auto_repeat.off.onRelease = function(){
	this._parent.on._visible = true;
	pref_menu.end_time._visible = true;
	auto_repeat = true;
	auto_repeat_status = "ready";
	clearInterval(repeat_timerID);
	setAutoRepeatInterval();
	auto_repeat_so.data.flag = true;
	auto_repeat_so.flush();
};
createToggleBtn(pref_menu,"add_id","右リストにID表示(リスト更新時に反映)",black12_fmt,3,17,67,0x808080);
createToggleBtn(pref_menu,"show_info","スクリーンに情報表示",black12_fmt,4,17,92,0x808080);
createToggleBtn(pref_menu,"copy_to_clip_board","IDをクリップボードにコピー",black12_fmt,5,17,117,0x808080);
createToggleBtn(pref_menu,"local_server","ローカルFLVサーバーを使う",black12_fmt,6,17,142,0x808080);
createToggleBtn(pref_menu,"mouse_wheel","ホイールシーク",black12_fmt,7,17,207,0x808080);
pref_menu.mouse_wheel.on.onRelease = function(){
	this._visible = false;
	pref_menu.mouse_reverse._visible = false;
	pref_menu.label_mouse_backward._visible = false;
	pref_menu.label_mouse_forward._visible = false;
	pref_menu.input_mouse_backward._visible = false;
	pref_menu.input_mouse_forward._visible = false;
	mouse_wheel = false;
	mouse_wheel_so.data.flag = false;
	mouse_wheel_so.flush();
};
pref_menu.mouse_wheel.off.onRelease = function(){
	this._parent.on._visible = true;
	pref_menu.mouse_reverse._visible = true;
	pref_menu.label_mouse_backward._visible = true;
	pref_menu.label_mouse_forward._visible = true;
	pref_menu.input_mouse_backward._visible = true;
	pref_menu.input_mouse_forward._visible = true;
	mouse_wheel = true;
	mouse_wheel_so.data.flag = true;
	mouse_wheel_so.flush();
};

createToggleBtn(pref_menu,"mouse_reverse","逆回転",black12_fmt,8,132,207,0x808080);
pref_menu.mouse_reverse.on.onRelease = function(){
	this._visible = false;
	mouse_reverse = false;
	mouse_wheel_so.data.reverse = false;
	mouse_wheel_so.flush();
};
pref_menu.mouse_reverse.off.onRelease = function(){
	this._parent.on._visible = true;
	mouse_reverse = true;
	mouse_wheel_so.data.reverse = true;
	mouse_wheel_so.flush();
};

createToggleBtn(pref_menu,"filter1","",black12_fmt,9,17,252,0x808080);
if(!filter1_on){pref_menu.filter1.on._visible = false;}
pref_menu.filter1.on.onRelease = function(){
	this._visible = false;
	filter_so.data.filter1_flag = false;
	filter_so.flush();
};
pref_menu.filter1.off.onRelease = function(){
	this._parent.on._visible = true;
	filter_so.data.filter1_flag = true;
	filter_so.flush();
};

createToggleBtn(pref_menu,"filter2","",black12_fmt,10,17,272,0x808080);
if(!filter2_on){pref_menu.filter2.on._visible = false;}
pref_menu.filter2.on.onRelease = function(){
	this._visible = false;
	filter_so.data.filter2_flag = false;
	filter_so.flush();
};
pref_menu.filter2.off.onRelease = function(){
	this._parent.on._visible = true;
	filter_so.data.filter2_flag = true;
	filter_so.flush();
};

createToggleBtn(pref_menu,"filter3","",black12_fmt,11,17,292,0x808080);
if(!filter3_on){pref_menu.filter3.on._visible = false;}
pref_menu.filter3.on.onRelease = function(){
	this._visible = false;
	filter_so.data.filter3_flag = false;
	filter_so.flush();
};
pref_menu.filter3.off.onRelease = function(){
	this._parent.on._visible = true;
	filter_so.data.filter3_flag = true;
	filter_so.flush();
};

createToggleBtn(pref_menu,"filter4","",black12_fmt,12,17,312,0x808080);
if(!filter4_on){pref_menu.filter4.on._visible = false;}
pref_menu.filter4.on.onRelease = function(){
	this._visible = false;
	filter_so.data.filter4_flag = false;
	filter_so.flush();
};
pref_menu.filter4.off.onRelease = function(){
	this._parent.on._visible = true;
	filter_so.data.filter4_flag = true;
	filter_so.flush();
};
createSquareBtn(pref_menu,"apply_filter","→今すぐ適用",white12b_fmt,90,18,18,240,232,0x303030);
pref_menu.apply_filter.onRelease = function(){
	custom_filter_message_count=0;
	updateFilter("clear_filter");
	filter1_flag = new Array();
	filter2_flag = new Array();
	filter3_flag = new Array();
	filter4_flag = new Array();
	loadCustomFilter();
	updateLogList("clear");
	clearEmphMes("both");
	showInfoOnMainBar("フィルターの変更を適用しました");
};
createSquareBtn(pref_menu,"end_time","→リピートの終点を指定",white12b_fmt,140,18,19,273,42,0x303030);
pref_menu.end_time.onRelease = function(){
	createEndTimeInput();
};
createToggleBtn(pref_menu,"auto_play","自動再生許可",black12_fmt,13,246,67,0x808080);
createToggleBtn(pref_menu,"always_back_to_normal_mode","逐一通常モードに戻る(重いかも)",black12_fmt,14,160,92,0x808080);
createToggleBtn(pref_menu,"change_title","<title>タグをいぢる",black12_fmt,15,180,117,0x808080);
createToggleBtn(pref_menu,"use_javascript","JavaScriptを使う",black12_fmt,16,17,312+25,0x808080);
createToggleBtn(pref_menu,"wide_seek_bar","太いシークバー(次回読み込み時に反映)",black12_fmt,17,135,312+25,0x808080);

//その他のラベルとか入力エリアとか
pref_menu.createTextField("input_server_name",50,30,155,300,17);
pref_menu.createTextField("input_server_index",60,30,175,300,17);
pref_menu.createTextField("label_mouse_backward",70,210,197,1,1);
pref_menu.createTextField("input_mouse_backward",80,235,197,30,17);
pref_menu.createTextField("label_mouse_forward",90,265,197,1,1);
pref_menu.createTextField("input_mouse_forward",100,290,197,30,17);
pref_menu.createTextField("label_filter",110,10,222,1,1);
pref_menu.createTextField("input_filter1_name",120,30,242,25,17);
pref_menu.createTextField("input_filter1_commands",130,60,242,290,17);
pref_menu.createTextField("input_filter2_name",140,30,262,25,17);
pref_menu.createTextField("input_filter2_commands",150,60,262,290,17);
pref_menu.createTextField("input_filter3_name",160,30,282,25,17);
pref_menu.createTextField("input_filter3_commands",170,60,282,290,17);
pref_menu.createTextField("input_filter4_name",180,30,302,25,17);
pref_menu.createTextField("input_filter4_commands",190,60,302,290,17);
pref_menu.createTextField("label_version",200,140,5,1,1);

//大量にあるのでループで設定
for(var o in pref_menu){
	var t;
	switch(o){
		case "input_server_name" : t = local_server_name[0]; break;
		case "input_server_index" : t = local_server_index[0]; break;
		case "label_mouse_backward" : t = "後退"; break;
		case "input_mouse_backward" : t = mouse_backward; break;
		case "label_mouse_forward" : t = "前進"; break;
		case "input_mouse_forward" : t = mouse_forward; break;
		case "label_filter" : t = "フィルター(次回読み込み時に反映)"; break;
		case "input_filter1_name" : t = filter1_name; break;
		case "input_filter1_commands" : t = filter1_commands; break;
		case "input_filter2_name" : t = filter2_name; break;
		case "input_filter2_commands" : t = filter2_commands; break;
		case "input_filter3_name" : t = filter3_name; break;
		case "input_filter3_commands" : t = filter3_commands; break;
		case "input_filter4_name" : t = filter4_name; break;
		case "input_filter4_commands" : t = filter4_commands; break;
		case "label_version" : t = version; break;
		default : t = undefined;
	}
	if(t != undefined && (o.substr(0,6) == "label_" || o.substr(0,11) == "input_mouse")){
		pref_menu[o].text = t;
		pref_menu[o].type = "dynamic";
		pref_menu[o].border = false;
		pref_menu[o].selectable = false;
		pref_menu[o].background = false;
		pref_menu[o].autoSize = true;
		pref_menu[o].tabEnabled = false;
		pref_menu[o].setTextFormat(black12_fmt);
	}else if(t != undefined && o.substr(0,6) == "input_"){
		pref_menu[o].text = t;
		pref_menu[o].type = "input";
		pref_menu[o].border = true;
		pref_menu[o].background = false;
		pref_menu[o].autoSize = false;
		pref_menu[o].tabEnabled = true;
		pref_menu[o].setTextFormat(black12_fmt);
	}
}

pref_menu.input_server_name.onChanged = function(){
	local_server_so.data.name = pref_menu.input_server_name.text;
	if(pref_menu.input_server_index.text == ""){
		local_server_so.data.index = pref_menu.input_server_name.text;
	} else {
		local_server_so.data.index = pref_menu.input_server_index.text;
	}
	local_server_so.flush();
};
pref_menu.input_server_index.onChanged = pref_menu.input_server_name.onChanged;

pref_menu.input_filter1_name.onChanged = function(){
	filter_so.data.filter1_commands = pref_menu.input_filter1_commands.text;
	filter_so.data.filter2_commands = pref_menu.input_filter2_commands.text;
	filter_so.data.filter3_commands = pref_menu.input_filter3_commands.text;
	filter_so.data.filter4_commands = pref_menu.input_filter4_commands.text;
	filter_so.data.filter1_name = pref_menu.input_filter1_name.text.charAt(0);
	filter_so.data.filter2_name = pref_menu.input_filter2_name.text.charAt(0);
	filter_so.data.filter3_name = pref_menu.input_filter3_name.text.charAt(0);
	filter_so.data.filter4_name = pref_menu.input_filter4_name.text.charAt(0);
	filter_so.flush();
};
pref_menu.input_filter2_name.onChanged = pref_menu.input_filter1_name.onChanged;
pref_menu.input_filter3_name.onChanged = pref_menu.input_filter1_name.onChanged;
pref_menu.input_filter4_name.onChanged = pref_menu.input_filter1_name.onChanged;
pref_menu.input_filter1_commands.onChanged = pref_menu.input_filter1_name.onChanged;
pref_menu.input_filter2_commands.onChanged = pref_menu.input_filter1_name.onChanged;
pref_menu.input_filter3_commands.onChanged = pref_menu.input_filter1_name.onChanged;
pref_menu.input_filter4_commands.onChanged = pref_menu.input_filter1_name.onChanged;

function openPrefMenu(){
	pref_menu._visible = true;
	if(auto_repeat){
		pref_menu.auto_repeat.on._visible = true;
		pref_menu.end_time._visible = true;
	}else{
		pref_menu.auto_repeat.on._visible = false;
		pref_menu.end_time._visible = false;
	}
	if(auto_link){
		pref_menu.auto_link.on._visible = true;
	}else{
		pref_menu.auto_link.on._visible = false;
	}
	if(add_id){
		pref_menu.add_id.on._visible = true;
	}else{
		pref_menu.add_id.on._visible = false;
	}
	if(show_info){
		pref_menu.show_info.on._visible = true;
	}else{
		pref_menu.show_info.on._visible = false;
	}
	if(copy_to_clip_board){
		pref_menu.copy_to_clip_board.on._visible = true;
	}else{
		pref_menu.copy_to_clip_board.on._visible = false;
	}
	if(local_server){
		pref_menu.local_server.on._visible = true;
	}else{
		pref_menu.local_server.on._visible = false;
	}
	if(mouse_wheel){
		pref_menu.mouse_wheel.on._visible = true;
		if(mouse_reverse){
			pref_menu.mouse_reverse.on._visible = true;
		}else{
			pref_menu.mouse_reverse.on._visible = false;
		}
		pref_menu.label_mouse_backward._visible = true;
		pref_menu.input_mouse_backward._visible = true;
		pref_menu.label_mouse_forward._visible = true;
		pref_menu.input_mouse_forward._visible = true;
	}else{
		pref_menu.mouse_wheel.on._visible = false;
		pref_menu.mouse_reverse.on._visible = false;
		pref_menu.label_mouse_backward._visible = false;
		pref_menu.input_mouse_backward._visible = false;
		pref_menu.label_mouse_forward._visible = false;
		pref_menu.input_mouse_forward._visible = false;
	}
	if(auto_play){
		pref_menu.auto_play.on._visible = true;
	}else{
		pref_menu.auto_play.on._visible = false;
	}
	if(always_back_to_normal_mode){
		pref_menu.always_back_to_normal_mode.on._visible = true;
	}else{
		pref_menu.always_back_to_normal_mode.on._visible = false;
	}
	if(change_title){
		pref_menu.change_title.on._visible = true;
	}else{
		pref_menu.change_title.on._visible = false;
	}
	if(use_javascript){
		pref_menu.use_javascript.on._visible = true;
	}else{
		pref_menu.use_javascript.on._visible = false;
	}
	if(wide_seek_bar){
		pref_menu.wide_seek_bar.on._visible = true;
	}else{
		pref_menu.wide_seek_bar.on._visible = false;
	}
}

function closePrefMenu(){
	pref_menu._visible = false;
}

function createEndTimeInput(){
	if(end_time_input == undefined){
		closePrefMenu();
		updateNGIDMenu("close");

		createEmptyMovieClip("end_time_input",29000);
		end_time_input.createEmptyMovieClip("bg",1);
		end_time_input.bg.lineStyle(1,0x000000,100);
		end_time_input.bg.beginFill(0xffffff,100);
//		var w = 542;
		var w = nico.controller._width - 2;
		end_time_input.bg.moveTo(-w/2,-30);
		end_time_input.bg.lineTo(w/2,-30);
		end_time_input.bg.lineTo(w/2,30);
		end_time_input.bg.lineTo(-w/2,30);
		end_time_input.bg.lineTo(-w/2,-30);
		end_time_input.bg.endFill();
		end_time_input.bg.onPress = function(){
			end_time_input.startDrag();
		};
		end_time_input.bg.onRelease = function(){
			end_time_input.stopDrag();
		};
		end_time_input.bg.onReleaseOutside = end_time_input.bg.onRelease;
		end_time_input._x = nico.controller._x + w/2 - 1;
		end_time_input._y = nico.videowindow._y + nico.videowindow._height - 100;

		end_time_input.createEmptyMovieClip("window",2);

		createSquareBtn(end_time_input.window,"set","→現在時間をセット→",white12b_fmt,150,20,1,0,-13,0x303030);
		end_time_input.window.set.onRelease = function(){
			end_time_input.window.input.text = end_time_input.window.now.text;
			end_time_input.window.input.setTextFormat(red14b_fmt);
		};

		createSquareBtn(end_time_input.window,"apply","適用",white12b_fmt,70,20,2,-90,13,0x303030);
		end_time_input.window.apply.onRelease = function(){
			var check_end_time = Number(end_time_input.window.input.text);
			if(check_end_time > 0){
				end_time = check_end_time;
			}else{
				return;
			}
			var num_found = false;
			for(var i=0; i<end_time_ary.length; i++){
				if(end_time_ary[i].number == VIDEO){
					end_time_ary[i].time = end_time;
					num_found = true;
					break;
				}
			}
			if(!num_found){
				end_time_ary.push({number:VIDEO, time:end_time});
			}
			auto_repeat_so.data.flag = auto_repeat;
			auto_repeat_so.data.end_time_ary = end_time_ary;
			auto_repeat_so.flush();
			end_time_input.window.input.setTextFormat(black14b_fmt);
		};

		createSquareBtn(end_time_input.window,"del","クリア",white12b_fmt,70,20,3,0,13,0x303030);
		end_time_input.window.del.onRelease = function(){
			end_time = 0;
			clearInterval(repeat_timerID);
			auto_repeat_status = "ready";
			for(var i=0; i<end_time_ary.length; i++){
				if(end_time_ary[i].number == VIDEO){
					end_time_ary.splice(i,1);
					break;
				}
			}
			auto_repeat_so.data.flag = auto_repeat;
			auto_repeat_so.data.end_time_ary = end_time_ary;
			auto_repeat_so.flush();
			end_time_input.window.input.text = end_time;
			end_time_input.window.input.setTextFormat(black14b_fmt);
		};

		createSquareBtn(end_time_input.window,"close","閉じる",white12b_fmt,70,20,4,90,13,0x303030);
		end_time_input.window.close.onRelease = function(){
			end_time_input.removeMovieClip();
			delete timeLine.end_time_input.onEnterFrame;
			Mouse.removeListener(endTimeWheelListener);
		};

		end_time_input.window.createTextField("now",5,-100,-23,40,20);
		end_time_input.window.now.selectable = false;
		end_time_input.window.now.border = false;
		end_time_input.window.now.background = false;
		end_time_input.window.now.autoSize = true;
		end_time_input.window.now.wordWrap = false;
		end_time_input.window.now.text = nico.player.__play__headtime();
		end_time_input.window.now.setTextFormat(black14b_fmt);
		setEndTimeInputInterval();

		end_time_input.window.createTextField("input",6,100,-23,40,20);
		end_time_input.window.input.selectable = false;
		end_time_input.window.input.border = false;
		end_time_input.window.input.background = false;
		end_time_input.window.input.autoSize = true;
		end_time_input.window.input.wordWrap = false;
		end_time_input.window.input.text = end_time;
		end_time_input.window.input.setTextFormat(black14b_fmt);

		var endTimeWheelListener = new Object();
		endTimeWheelListener.onMouseWheel = function(delta,target){
			while(target != undefined){
				if(target == end_time_input){break;}
				target = target._parent;
			}
			if(target == end_time_input){
				if(delta > 0){
					var num = Number(end_time_input.window.input.text) + 0.1;
				}else if(delta < 0){
					var num = Number(end_time_input.window.input.text) - 0.1;
				}
				if(num <= 0){num = 0.1;}
				end_time_input.window.input.text = num;
				end_time_input.window.input.setTextFormat(red14b_fmt);
			}
		};
		Mouse.addListener(endTimeWheelListener);
	}
}

//★★★★★★★★★★★★★オートリンクのウィンドウ(23000) ★★★★★★★★★★★★★
//link_thumb.thumb0_0.thumbに自動リンクの1個目のサムネが読み込まれる
//link_thumb.thumb1_0.thumbにマイリスト1個目の1個目のサムネ
//link_thumb.tab0 自動リンクのタブ tab1 マイリスト1個目のタブ
function createLinkTab(name,num,color){
	//リンクウィンドウにタブを作る
	//tab0自動リンク(深度10000) tab1～うｐ主のマイリスト(深度10001～)
	//非アクティブになると深度がマイナスになる
	//なんだけどマイナスの深度って消せなくなるんだっけ・・？
	//表示上は問題ないからいいか
	var h = 20;
	var w = 99;
	var depth = 10000 + num;
	var path = _root.link_thumb;
	var tab = path.createEmptyMovieClip("tab"+num,depth);
	tab._visible = false;
	tab.beginFill(color,100);
	tab.lineStyle(1,0xf0f0f0,100);
	tab.moveTo(0,0);
	tab.lineTo(w,0);
	tab.lineStyle(1,0x000000,100);
	tab.lineTo(w-5,-h+2);
	tab.curveTo(w-5-1,-h+1,w-5-2,-h);
	tab.lineTo(5+2,-h);
	tab.curveTo(5+1,-h+1,5,-h+2);
	tab.lineTo(0,0);
	tab.endFill();

	tab.createTextField("info",1,0,0,100,20);
	tab.info.type = "dynamic";
	tab.info.border = false;
	tab.info.selectable = false;
	tab.info.background = false;
	tab.info.autoSize = false;
	tab.tabEnabled = false;
	tab.info.text = name;
	tab.info.setTextFormat(black12_fmt);
	tab.info._x = 0 + 5;
	tab.info._y = 0 - tab.info._height;

	var ol1 = tab.createEmptyMovieClip("over_lay_white",2);
	ol1._alpha = 0;
	ol1.beginFill(0xffffff,100);
	ol1.moveTo(0,0);
	ol1.lineTo(w,0);
	ol1.lineTo(w-5,-h+2);
	ol1.curveTo(w-5-1,-h+1,w-5-2,-h);
	ol1.lineTo(5+2,-h);
	ol1.curveTo(5+1,-h+1,5,-h+2);
	ol1.lineTo(0,0);
	ol1.endFill();

	var ol2 = tab.createEmptyMovieClip("over_lay_black",3);
	ol2._alpha = 0;
	ol2.beginFill(0x000000,100);
	ol2.moveTo(0,0);
	ol2.lineTo(w,0);
	ol2.lineTo(w-5,-h+2);
	ol2.curveTo(w-5-1,-h+1,w-5-2,-h);
	ol2.lineTo(5+2,-h);
	ol2.curveTo(5+1,-h+1,5,-h+2);
	ol2.lineTo(0,0);
	ol2.endFill();

	var ol3 = tab.createEmptyMovieClip("over_lay_red",4);
	ol3._visible = false;
	ol3.beginFill(0xff0000,30);
	ol3.moveTo(0,0);
	ol3.lineTo(w,0);
	ol3.lineTo(w-5,-h+2);
	ol3.curveTo(w-5-1,-h+1,w-5-2,-h);
	ol3.lineTo(5+2,-h);
	ol3.curveTo(5+1,-h+1,5,-h+2);
	ol3.lineTo(0,0);
	ol3.endFill();

	tab.onRollOver = function(){
		this.over_lay_black._alpha = 10;
	};
	tab.onRollOut = function(){
		this.over_lay_black._alpha = 0;
	};
	tab.onReleaseOutside = tab.onRollOut;
	tab.onRelease = function(){
		links_num[0] = num;
		links_num[1] = 0;
		updateLinkTab(num,true);
		updateLinkThumb("update",num,0);
		if(num == 0){
			flashTab("stop");
		}
	};
}
createLinkTab("自動リンク",0,0xf0f0f0);
createLinkTab("マイリスト1",1,0xf0f0f0);
createLinkTab("マイリスト2",2,0xf0f0f0);
createLinkTab("マイリスト3",3,0xf0f0f0);

//タブの位置調整及び、指定したタブをアクティブに
function updateLinkTab(num,active){
	var w = 99;
	var path = _root.link_thumb;
	var tab = path["tab"+num];
	tab._visible = true;
	tab.over_lay_white._alpha = 50;
	tab.swapDepths(-Math.abs(tab.getDepth()));//ウィンドウより後ろへ
	if(path.tab0._visible){
		path.tab0._x = 0;
		path.tab1._x = w;
		path.tab2._x = w*2;
		path.tab3._x = w*3;
	}else{
		path.tab1._x = 0;
		path.tab2._x = w*1;
		path.tab3._x = w*2;
	}
	if(active){
		for(var i=0; i<4; i++){
			var tab = path["tab"+i];
			if(i==num){//アクティブにしたいタブ
				tab.over_lay_white._alpha = 0;
				tab.swapDepths(Math.abs(tab.getDepth()));//ウィンドウより前面へ
			}else{
				tab.over_lay_white._alpha = 50;
				tab.swapDepths(-Math.abs(tab.getDepth()));//ウィンドウより後ろへ
			}
		}
	}
}

link_thumb.swapDepths(23000);
link_thumb._visible = false;
link_thumb.base.swapDepths(0);
link_thumb.ameba.swapDepths(20);
link_thumb.ameba._visible = false;
link_thumb.ameba._x = 1;
link_thumb.ameba._y = 22;
link_thumb.photozou.swapDepths(21);
link_thumb.photozou._visible = false;
link_thumb.photozou._x = 1;
link_thumb.photozou._y = 22;
link_thumb.base.onPress = function (){
	goTopDepth(link_thumb);
	var xm = link_thumb._xmouse;
	var ym = link_thumb._ymouse;
	if(ym>0 && ym<20){
		if(xm>0 && xm<375){
			link_thumb.startDrag();
		}
	}
};
link_thumb.base.onRelease = function (){
	link_thumb.stopDrag("");
	var xm = link_thumb._xmouse;
	var ym = link_thumb._ymouse;
	if(ym>0 && ym<20){
		if(xm>376 && xm<398){
			link_thumb._visible = false;
			main_bar.link._visible = true;
			flashTab("stop");
		}
	}else if(ym>20 && ym<120){
		var num = links[links_num[0]][links_num[1]].number;
		if(num != undefined){
			var url = "http://www.nicovideo.jp/watch/" + num;
			if(xm>0 && xm<130){
				getURL(url,"_blank");
				if(nico.player.__get__state() == "playing") {
					nico.player.pause();
				}
			}
		}
	}else if(ym>120){
		if(links[links_num[0]][links_num[1]].user_id != undefined){
			emphID(links[links_num[0]][links_num[1]].user_id);
		}
	}
};

link_thumb.createTextField("header_left",2,0,0,320,17);
link_thumb.header_left.type = "dynamic";
link_thumb.header_left.selectable = false;
link_thumb.header_left.border = false;
link_thumb.header_left.background = false;
link_thumb.header_left.autoSize = false;
link_thumb.header_left.text = "";
link_thumb.header_left.setTextFormat(black12b_fmt);

link_thumb.createTextField("header_right",3,321,0,0,0);
link_thumb.header_right.type = "dynamic";
link_thumb.header_right.selectable = false;
link_thumb.header_right.border = false;
link_thumb.header_right.background = false;
link_thumb.header_right.autoSize = true;
link_thumb.header_right.text = "";
link_thumb.header_right.setTextFormat(black12b_fmt);

link_thumb.createTextField("footer",4,0,123,398,20);
link_thumb.footer.type = "dynamic";
link_thumb.footer.selectable = false;
link_thumb.footer.border = false;
link_thumb.footer.background = false;
link_thumb.footer.autoSize = false;
link_thumb.footer.wordWrap = false;
link_thumb.footer.text = "";
link_thumb.footer.setTextFormat(black11_fmt);

link_thumb.createTextField("title",5,131,22,398-131-2,17+3);
link_thumb.title.type = "dynamic";
link_thumb.title.selectable = false;
link_thumb.title.border = false;
link_thumb.title.background = true;
link_thumb.title.backgroundColor = 0xffffe0;
link_thumb.title.autoSize = false;
link_thumb.title.wordWrap = true;
link_thumb.title.text = "";
link_thumb.title.setTextFormat(black12b_fmt);

link_thumb.createTextField("info",6,131,42,398-131-2,79);
link_thumb.info.type = "dynamic";
link_thumb.info.selectable = false;
link_thumb.info.border = false;
link_thumb.info.background = false;
link_thumb.info.autoSize = false;
link_thumb.info.wordWrap = true;
link_thumb.info.text = "";
link_thumb.info.setTextFormat(black12_fmt);

link_thumb.createTextField("thumb_status",7,0,21,1,1);
link_thumb.thumb_status.type = "dynamic";
link_thumb.thumb_status.selectable = false;
link_thumb.thumb_status.border = false;
link_thumb.thumb_status.background = false;
link_thumb.thumb_status.autoSize = true;
link_thumb.thumb_status.wordWrap = false;

createSquareBtn(link_thumb,"open_blur","B",white12b_fmt,20,20,9999,120,112,0x303030);
link_thumb.open_blur.onRelease = function(){
	var num = links[links_num[0]][links_num[1]].number;
	if(num != undefined){
		var url = "http://www.nicovideo.jp/watch/" + links[links_num[0]][links_num[1]].number;
		doJavaScript("window.open('"+url+"').blur();");
	}
};

createSquareBtn(link_thumb,"load","情報を読み込み",white12b_fmt,100,20,10,340,105,0x303030);
link_thumb.load.onRelease = function(){
	if(links_num[0] == 0){//自動リンクの場合
		this._visible = false;
		var tThumb = links[links_num[0]][links_num[1]];
		tThumb.title = "";
		link_thumb.title.text = tThumb.title;
		tThumb.info = "読み込み中";
		link_thumb.info.text = tThumb.info;
		link_thumb.info.setTextFormat(black12_fmt);

		var link_info = new LoadVars();
		link_info.onData = function(src){
			var info = "", title = "";
			if(src != undefined){
				var start_keys = new Array("<h1>","<a ",">");
				var end_key = "</a>";
				title = searchHTML(src,start_keys,end_key);
				if(title != null){
					title = replaceSentence(title,"&amp;","&");//とりあえずありがちなのだけ変換
					title = replaceSentence(title,"&#039;","'");//とりあえずありがちなのだけ変換
				}else{
					title = "HTML解析失敗";
				}
				var start_keys = new Array("</h1>","<p class=\"TXT12",">");
				var end_key = "</p>";
				info = searchHTML(src,start_keys,end_key);
				if(info != null){
					info = replaceSentence(info,["\n","\r"],"");//改行削除
					info = removeHTMLTag(info);//他のhtmlタグ削除
					info = replaceSentence(info,[" ","　"],"");//スペース削除
					info = replaceSentence(info,"&amp;","&");//とりあえずありがちなのだけ変換
					info = replaceSentence(info,"&#039;","'");//とりあえずありがちなのだけ変換
				}else{
					info = "HTML解析失敗\n" + src;
				}
			}else{
				title = "読み込み失敗";
				info = undefined;
			}
			tThumb.title = title;
			tThumb.info = info;
			updateLinkThumb("update",links_num[0],links_num[1]);
		};
		link_info.load("http://www.nicovideo.jp/watch/" + tThumb.number);
	}else if(links_num[0] > 0){//マイリストの場合
		//↓バックアップ マイリストは読み込みが終わったあとにサムネを取得開始するので
		//↓読み込み中にタブ切り替えとかされると、どのリストのサムネか分からなくなってしまうため
		var backup = links_num.slice(0);
		var tmp_num = backup[0];
		this._visible = false;
		var tThumb = links[tmp_num];
		tThumb.title = "";
		link_thumb.title.text = tThumb.title;
		tThumb.info = "読み込み中";
		link_thumb.info.text = tThumb.info;
		link_thumb.info.setTextFormat(black12_fmt);
		var link_info = new LoadVars();
		link_info.onData = function(src){
			var info = "", title = "";
			if(src != undefined){
				var start_keys = new Array("<h2 ",">");
				var end_key = "</h2>";
				title = searchHTML(src,start_keys,end_key);
				if(title == null){title = "HTML解析失敗";}

				var start_keys = new Array("</h2>","<p",">");
				var end_key = "</p>";
				info = searchHTML(src,start_keys,end_key);
				if(info == null){info = "HTML解析失敗\n" + src;}

				start_keys = new Array("<h3 ","<a ",">");
				end_key = "</a>";
				var title_ary = searchHTMLs(src,start_keys,end_key);

				start_keys = new Array("</h3>","<p ",">");
				end_key = "</p>";
				var info_ary = searchHTMLs(src,start_keys,end_key);

				start_keys = new Array("<a href=\"watch/");
				end_key = "\">";
				var number_ary = searchHTMLs(src,start_keys,end_key);

				start_keys = new Array("<a href=\"watch/","<img ","src=\"");
				end_key = "\"";
				var thumb_ary = searchHTMLs(src,start_keys,end_key);

				if(title_ary.length > 0 && title_ary.length == info_ary.length && title_ary.length == number_ary.length && title_ary.length == thumb_ary.length){
					for(var i=0; i<title_ary.length; i++){
						tThumb[i] = new Array();
						title_ary[i] = replaceSentence(title_ary[i],"&amp;","&");//とりあえずありがちなの
						title_ary[i] = replaceSentence(title_ary[i],"&#039;","'");//とりあえずありがちなの
						tThumb[i].title = title_ary[i];
						info_ary[i] = replaceSentence(info_ary[i],["\n","\r"],"");//改行削除
						info_ary[i] = removeHTMLTag(info_ary[i]);//他のhtmlタグ削除
						info_ary[i] = replaceSentence(info_ary[i],"&amp;","&");//とりあえずありがちなのだけ
						info_ary[i] = replaceSentence(info_ary[i],"&#039;","'");//とりあえずありがちなのだけ
						tThumb[i].info = info_ary[i];
						tThumb[i].number = number_ary[i];
						tThumb[i].thumb_status = "順番待ち";
					}
					//サムネ読み込み開始
					for(var i=0; i<thumb_ary.length; i++){
						var thumb_window = link_thumb.createEmptyMovieClip("thumb"+tmp_num+"_"+i,1000+1000*tmp_num+i);
						thumb_window._visible = false;
						thumb_window._x = 1;
						thumb_window._y = 22;
						thumb_window._width = 130;
						thumb_window._height = 100;
						buffer_ary.push({list_num:tmp_num, thumb_num:i, url:thumb_ary[i], timeout1:0, timeout2:0, retry:0, status:"ready"});
					}
				}else{
					title = "HTML解析失敗";
					info = "HTML解析失敗\n" + src;
				}
			}else{
				title = "読み込み失敗";
				info = undefined;
			}
			tThumb.title = title;
			tThumb.info = info;
			updateLinkThumb("update",links_num[0],links_num[1]);
		};
		link_info.load(my_lists[tmp_num-1]);
	}
};

//add 自動リンク生成
//next 次のサムネに表示切替
//before 前のサムネに表示切替
//update l_num番のリストのt_num番のサムネに切り替え
function updateLinkThumb(mode,l_num,t_num){
	if(mode == "add"){
		var num = links[0].length - 1;//自動リンクの一番最後 すなわちaddするであろうリンク
		goTopDepth(link_thumb);
		if(link_thumb._visible && links_num[0] > 0){//マイリストみてる時
			updateLinkTab(0,false);
			flashTab("start");
		}else{
			link_thumb._visible = true;
			links_num = [0,num];
			updateLinkTab(0,true);
			main_bar.link._visible = false;
		}
		var first_name = links[0][num].number.substr(0,2);//sm am fzとか
		var last_name = links[0][num].number.substr(2);//数字
		var thumb_window = link_thumb.createEmptyMovieClip("thumb0_"+num, 100+num);
		thumb_window._visible = false;
		thumb_window._x = 1;
		thumb_window._y = 22;
		thumb_window._width = 100;
		thumb_window._height = 130;
		if(first_name == "sm" || first_name == "ca"){
			var url = "http://tn-skr.smilevideo.jp/smile?i=" + last_name;
			buffer_ary.unshift({list_num:0, thumb_num:num, url:url, timeout1:0, timeout2:0, retry:0, status:"ready"});
//		}else if(first_name == "am" || first_name == "fz"){
//			thumb_window.createEmptyMovieClip("thumb",1);
		}
		updateLinkThumb("update",links_num[0],links_num[1]);
		return;
	}

	//ここからサムネの表示反映
	var bNum = links_num.slice(0);
	if(mode == "next"){links_num[1]++;}
	else if(mode == "before"){links_num[1]--;}
	else if(mode == "update"){links_num[0] = l_num; links_num[1] = t_num;}
	if(link_thumb["thumb"+links_num[0]+"_"+links_num[1]] == undefined){
		links_num = bNum.slice(0);
	}
	var first_name = links[links_num[0]][links_num[1]].number.substr(0,2);//sm am fzとか
	for(var i=0; i<links.length; i++){
		for(var j=0; j<links[i].length; j++){
			var thumb_window = link_thumb["thumb"+i+"_"+j];
			if(i == links_num[0] && j == links_num[1]){
				if(first_name == "sm" || first_name == "ca"){
					thumb_window._visible = true;
					thumb_window._width = 130;
					thumb_window._height = 100;
				}else if(first_name == "am"){
					link_thumb.ameba._visible = true;
				}else if(first_name == "fz"){
					link_thumb.photozou._visible = true;
				}
			}else{
				thumb_window._visible = false;
				if(first_name != "am"){
					link_thumb.ameba._visible = false;
				}
				if(first_name != "fz"){
					link_thumb.photozou._visible = false;
				}
			}
		}
	}

	//ここからtextfieldの表示反映
	if(links[links_num[0]].title != undefined){
		link_thumb.header_left.text = links[links_num[0]].title;
	}else{
		link_thumb.header_left.text = links[links_num[0]][links_num[1]].number;
	}
	link_thumb.header_left.setTextFormat(black12b_fmt);
	if(links[links_num[0]].length > 0){
		link_thumb.header_right.text = " (" + (links_num[1]+1) + "/" + links[links_num[0]].length + ")";
	}else{
		link_thumb.header_right.text = "";
	}
	link_thumb.header_right.setTextFormat(black12b_fmt);
	link_thumb.footer.text = links[links_num[0]][links_num[1]].message;
	link_thumb.footer.setTextFormat(black10_fmt);
	link_thumb.footer.hscroll = 0;
	link_thumb.title.text = links[links_num[0]][links_num[1]].title;
	link_thumb.title.setTextFormat(black12b_fmt);
	link_thumb.info.text = links[links_num[0]][links_num[1]].info;
	link_thumb.info.setTextFormat(black12_fmt);
	link_thumb.info.scroll = 0;
	adjustTitleHeight();
	link_thumb.load._visible = false;
	link_thumb.thumb_status.text = links[links_num[0]][links_num[1]].thumb_status;
	link_thumb.thumb_status.setTextFormat(black12_fmt);
	if(links_num[0] == 0 && links[links_num[0]][links_num[1]].info == undefined){
		link_thumb.load._visible = true;
	}else if(links_num[0] > 0 && links[links_num[0]].info == undefined){
		link_thumb.load._visible = true;
	}
}

//link_thumb.titleの高さを文字の長さに応じて1段にしたり2段にしたり調整する
function adjustTitleHeight(){
	link_thumb.title.wordWrap = false;
	if(link_thumb.title.textWidth > 260){
		link_thumb.title.wordWrap = true;
		link_thumb.title._height = 17+3+17;
		link_thumb.info._y = 42+17;
		link_thumb.info._height = 79-17;
	}else{
		link_thumb.title.wordWrap = false;
		link_thumb.title._height = 17+3;
		link_thumb.info._y = 42;
		link_thumb.info._height = 79;
	}
}

//配列start_keysでhtmlを頭からindexOfで検索していって開始地点を探す
//探しだしたら、そこからend_keyまでを抜き出す
function searchHTML(html,start_keys,end_key){
	for(var i=0; i<start_keys.length; i++){
		if(html.indexOf(start_keys[i]) < 0){
			return null;
		}else{
			html = html.substr(html.indexOf(start_keys[i]) + start_keys[i].length);
		}
	}
	if(html.indexOf(end_key) < 0){
		return null;
	}else{
		html = html.substring(0,html.indexOf(end_key));
	}
	return html;
}

//searchHTMLの複数版　探したい内容が複数ある場合
//返答は配列で、1個もみつからないと空の配列
function searchHTMLs(html,start_keys,end_key){
	var tmp = html;
	var count = 1;
	var result_ary = new Array();
	while(count <= 500){
		tmp = html;
		for(var i=0; i<start_keys.length; i++){
			if(tmp.indexOf(start_keys[i]) < 0){
				return result_ary;
			}else{
				tmp = tmp.substr(tmp.indexOf(start_keys[i]) + start_keys[i].length);
			}
		}
		html = tmp;
		if(tmp.indexOf(end_key) < 0){
			return result_ary;
		}else{
			tmp = tmp.substring(0, tmp.indexOf(end_key));
			result_ary.push(tmp);
		}
		count++;
	}
	return result_ary;
}

//htmlのタグっぽいのを全部取り除く
//mingだとtextFieldのhtmlタグがうまくいかない
function removeHTMLTag(html){
	while(html.length > 0){
		var start_tag_index = html.indexOf("<");
		if(start_tag_index >= 0){
			var end_tag_index = html.indexOf(">",start_tag_index);
			if(end_tag_index >= 0){
				html = html.substring(0,start_tag_index) + html.substr(end_tag_index + 1);
			}else{
				break;
			}
		}else{
			break;
		}
	}
	return html;
}


//★★★★★★★★★★★★★テスト用ボタン 10000～★★★★★★★★★★★★★

if(test_mode){
createSquareBtn(main_bar,"test","テスト",white12b_fmt,60,20,10000,900,15,0x303030);
main_bar.test._x = 915;
main_bar.test._y = 11;
main_bar.test.onRelease = function(){
//テストしたいScript
//	nico.connectBoard(true);

};
}
//★★★★★★★★★★★★★ログリスト周辺 20000★★★★★★★★★★★★★
loglist_menu.swapDepths(20000);
loglist_menu.tab._visible = false;
loglist_menu.tab.onPress = function(){};

//NGID追加ボタン リストのあたりに表示する1
createSquareBtn(loglist_menu,"add_id","NGIDに追加",white12b_fmt,80,20,1,350,35,0x303030);
loglist_menu.add_id.onRelease = function(){
	this._visible = false;
	cand_ng_id = deleteRepField(cand_ng_id,"user_id",false);
	updateFilter("add_id");
};
loglist_menu.add_id._visible = false;

//リストをノーマルに戻す リストのあたりに表示する2
createSquareBtn(loglist_menu,"normal_list","→通常モードに戻す",white12b_fmt,130,18,2,173,11,0x500000);
loglist_menu.normal_list.onRelease = function(){
	updateLogList("normal");
};
loglist_menu.normal_list._visible = false;


function updateFilter (mode,num){
	var i, ML;
	var update_info = false;

	if(mode == "add_id"){
		//NGID追加 フラグ立ててメッセージ消去 ng_idsに追加 ng_idsの重複チェック&削除
		//事前にcand_ng_id内の重複削除しておいたほうが早くなる
		update_info = true;
		i = 0;
		ML = ngid_filter_message_count;
		var myDate = new Date();
		var addDate = myDate.getTime();
		var addID,addMessage;
		var checked_ary = new Array();

//		var mes_ary = fwMessages.sortOn("user_id",16|8);//こうしたいがなぜかダメだった
		var mes_ary = fwMessages.slice(i,ML);//コピー
		mes_ary.sortOn("user_id",16);//user_id小さい順
		for(var j=0; j<cand_ng_id.length; j++){
			addID = cand_ng_id[j].user_id;
			addMessage = cand_ng_id[j].message;
			var result_nums = binarySearchS(mes_ary,"user_id",addID);
			if(result_nums.length > 0){
				for(var k=0; k<result_nums.length; k++){
					var no = mes_ary[result_nums[k]].no;
					NGIDFlagOn(no);
					if(filter5_on){//NGIDフィルターオンなら消す
						fwHideMessage(nico.Messages[no]);
					}
					if(k == result_nums.length - 1){//最後にヒットしたコメント
						addMessage = nico.Messages[no]._message;
					}
				}
			}
			ng_ids.push({user_id: addID, date: addDate, message: addMessage});
		}

		updateLogList("clear");
		cand_ng_id = new Array();//消去
		ng_ids.sortOn("user_id",16);//user_idの数値の小さい順
		ng_ids = deleteRepField(ng_ids,"user_id",true);
		ng_ids_so.data.ids = ng_ids;
		ng_ids_so.flush();
		showInfoOnMainBar("重複チェック＆NGID追加完了");
		if(always_open_ngid_menu || ngid_menu._visible){updateNGIDMenu("ng_ids");}
		clearEmphMes("both");
		showInfoOnBtn("filter5",ngid_filter_count);
	}

	else if(mode == "add_filter"){//フィルターオン
		update_info = true;
		_root["filter" + num + "_on"] = true;
		i = 0;
		var filter_flag;
		if(num < 5){
			ML = custom_filter_message_count;
			filter_flag = _root["filter" + num + "_flag"];
			showInfoOnMainBar("フィルター" + num + "を適用しました");
		}else if(num == 5){
			ML = ngid_filter_message_count;
			filter_flag = ngid_filter_flag;
			showInfoOnMainBar("NGIDを適用しました");
		}
		clearEmphMes("MessageSlots");
		var Mes = nico.Messages;
		while(i < ML){
			if(filter_flag[i]){
				fwHideMessage(Mes[i]);
			}
			Mes[i]._mine = false;//全部枠はずす
			i++;
		}
		if(list_mode != "normal"){
			updateLogList("clear");
		}
	}

	else if(mode == "check"){//新着メッセチェックしてフラグを立てる
		//まずNGIDから
		ML = fwMessages.length;
		i = ngid_filter_message_count;
		if(i<ML){
			update_info = true;
			var ngid_write_flag = false;
			var myDate = new Date();
			var addDate = myDate.getTime();
			var new_mes_ary = fwMessages.slice(i);
			var search_mode = checkSearchMode(new_mes_ary.length,ng_ids.length);//どれをソートするか決定
			if(search_mode == "new_mes_search"){
				new_mes_ary.sortOn("user_id",16);//user_idフィールドの数値の小さい順に並べる
				for(var j=0; j<ng_ids.length; j++){
					var result_nums = binarySearchS(new_mes_ary,"user_id",ng_ids[j].user_id);
					if(result_nums.length > 0){//IDヒットしたメッセージの配列が返ってきた
						ngid_write_flag = true;
						for(var k=0; k<result_nums.length; k++){
							var no = new_mes_ary[result_nums[k]].no;
							NGIDFlagOn(no);
							fwHideMessage(nico.Messages[no]);
							if(k == result_nums.length - 1){//最後にヒットしたメッセージと時間を格納
								ng_ids[j].date = addDate;
								ng_ids[j].message = nico.Messages[no]._message;
							}
						}
					}
				}
			}else if(search_mode == "ng_search"){
//				ng_ids.sortOn("user_id",16);//user_idフィールドの数値の小さい順に並べる
				for(var j=0; j<new_mes_ary.length; j++){
					var result_num = binarySearch(ng_ids,"user_id",new_mes_ary[j].user_id);
					if(result_num >= 0){//new_mes_ary[j]がNGID対象だったので
						ngid_write_flag = true;
						var no = new_mes_ary[j].no;
						NGIDFlagOn(no);
						fwHideMessage(nico.Messages[no]);
						ng_ids[result_num].date = addDate;
						ng_ids[result_num].message = new_mes_ary[j]._message;
					}
				}
			}else if(search_mode == "no_search"){//特に大きくないので総当り
				while(i < ML){//新着メッセのNGIDチェック
					var mes = nico.Messages[i];
					for(var j=0; j<ng_ids.length; j++){
						if(fwMessages[i].user_id == ng_ids[j].user_id){
							ngid_write_flag = true;
							NGIDFlagOn(i);
							fwHideMessage(mes);
							ng_ids[j].date = addDate;
							ng_ids[j].message = mes._message;
							break;
						}
					}
					i++;
				}
			}
			showInfoOnBtn("filter5",ngid_filter_count);
			ngid_filter_message_count = ML;
			if(ngid_write_flag){
				ng_ids_so.data.ids = ng_ids;
				ng_ids_so.flush();
			}
		}

		//次にカスタムフィルター
		i = custom_filter_message_count;
		if(i<ML){
			update_info = true;
			while(i < ML){//新着メッセのカスタムフィルターフラグ立て
				var mes = nico.Messages[i];
				for(var j=1; j<=4; j++){
					var hideFlag = true;
					if(filter_command_ary[j] == undefined){
						hideFlag = false;
					}
					if(hideFlag && filter_command_ary[j].place != undefined){
						hideFlag=false;
						for(var k=0; k<filter_command_ary[j].place.length; k++){
							if(filter_command_ary[j].place[k] == mes._place){
								hideFlag = true;
								break;
							}
						}
					}
					if(hideFlag && filter_command_ary[j].size != undefined){
						hideFlag=false;
						for(var k=0; k<filter_command_ary[j].size.length; k++){
							if(filter_command_ary[j].size[k] == mes._font.size){
								hideFlag=true;
								break;
							}
						}
					}
					if(hideFlag && filter_command_ary[j].color != undefined){
						hideFlag=false;
						for(var k=0; k<filter_command_ary[j].color.length; k++){
							if(filter_command_ary[j].color[k] == "all" && mes._color < 16777215){
								hideFlag=true;
								break;
							}else if(filter_command_ary[j].color[k] == mes._color){
								hideFlag=true;
								break;
							}
						}
					}
					if(hideFlag && filter_command_ary[j].vpos != undefined){
						hideFlag=false;
						for(var k=0; k<filter_command_ary[j].vpos.length; k++){
							if(filter_command_ary[j].vpos[k] - 2 <= mes._vpos && filter_command_ary[j].vpos[k] + 2 >= mes._vpos){
								hideFlag=true;
								break;
							}
						}
					}
					if(hideFlag && filter_command_ary[j].mes != undefined){
						hideFlag=false;
						for(var k=0; k<filter_command_ary[j].mes.length; k++){
							if(mes._message.indexOf(filter_command_ary[j].mes[k]) >= 0){
								hideFlag=true;
								break;
							}
						}
					}
					if(hideFlag){//フラグオン
						_root["filter" + j + "_flag"][i] = true;
						_root["filter" + j + "_count"]++;
					}
				}
				if((filter1_flag[i] && filter1_on) || (filter2_flag[i] && filter2_on) || (filter3_flag[i] && filter3_on) || (filter4_flag[i] && filter4_on)){
					fwHideMessage(mes);
				}
				i++;
			}
			showInfoOnBtn("filter1",filter1_count);
			showInfoOnBtn("filter2",filter2_count);
			showInfoOnBtn("filter3",filter3_count);
			showInfoOnBtn("filter4",filter4_count);
			custom_filter_message_count = ML;
		}
	}

	else if(mode == "clear_id"){
		update_info = true;
		i = 0;
		ML = fwMessages.length;
		ngid_filter_message_count = 0;
		ngid_filter_count = 0;
		ng_ids = new Array();
		ngid_filter_flag = new Array();
		ng_ids_so.data.ids = new Array();
		ng_ids_so.flush();
		cand_ng_id = new Array();
		var count = 0;
		while(i < ML){
			var mes = nico.Messages[i];
			if(mes._deleted == 1
				&& (!filter1_flag[i] || !filter1_on)
				&& (!filter2_flag[i] || !filter2_on)
				&& (!filter3_flag[i] || !filter3_on)
				&& (!filter4_flag[i] || !filter4_on)){
				cand_ng_id.push({user_id: fwMessages[i].user_id, date: 0, message: fwMessages[i]._message, vpos: fwMessages[i]._vpos, no:fwMessages[i].no});
				mes._mine = true;
				mes._deleted = 0;
				filter_count--;
				count++;
				var vpos = nico.player.__get__playheadtime();
				if(vpos >= mes._vstart && vpos <= mes._vend){
					nico.ShowMessage(mes);
				}
			}else if(mes._mine == true){
				mes._mine = false;
				var vpos = nico.player.__get__playheadtime();
				if(vpos >= mes._vstart && vpos <= mes._vend){
					nico.HideMessage(mes);
					nico.ShowMessage(mes);
				}
			}
			i++;
		}
		updateNGIDMenu("ng_ids");
		if(cand_ng_id.length > 0){
			updateLogList("cand_ng_id");
		}else{
			updateLogList("clear");
		}
		showInfoOnMainBar("NGIDをクリアしました(" + count + "件表示)");
		showInfoOnBtn("filter5",ngid_filter_count);
	}

	else if(mode == "clear_filter"){
		update_info = true;
		filter1_on = false;
		filter2_on = false;
		filter3_on = false;
		filter4_on = false;
		if(Key.isDown(ngid_off_key_code) || ngid_off_key_code == 0){filter5_on = false;}
		cand_ng_id = new Array();
		updateLogList("clear");
		ML = fwMessages.length;
		i = 0;
		var count = 0;//何件解除されたかカウント
		while(i < ML){
			var mes = nico.Messages[i];
			var flag;
			if(mes._deleted == 1 && (!ngid_filter_flag[i] || !filter5_on)){
				cand_ng_id.push({user_id: fwMessages[i].user_id, date: 0, message: fwMessages[i]._message, vpos: fwMessages[i]._vpos, no:fwMessages[i].no});
				mes._mine = true;
				mes._deleted = 0;
				filter_count--;
				count++;
				var vpos = nico.player.__get__playheadtime();
				if(vpos >= mes._vstart && vpos <= mes._vend){
					nico.ShowMessage(mes);
				}
			}else if(mes._deleted == 0 && mes._mine == true){
				mes._mine = false;
				var vpos = nico.player.__get__playheadtime();
				if(vpos >= mes._vstart && vpos <= mes._vend){
					nico.HideMessage(mes);
					nico.ShowMessage(mes);
				}
			}
			i++;
		}
		if(cand_ng_id.length > 0){updateLogList("cand_ng_id");}
		showInfoOnMainBar("フィルターを解除しました(" + count + "件表示)");
	}

	if(update_info){
		showFilterInfo(filter_count,ML);
		if(show_info){
			showInfoOnScreen(filter_count + "/" + ML, 60);
		}
	}
}

//NGIDフラグたててカウント++
function NGIDFlagOn(no){
	if(!ngid_filter_flag[no]){
		ngid_filter_count++;
		ngid_filter_flag[no] = true;
	}
}
function fwHideMessage(mes){
	if(mes._deleted == 0){
		mes._deleted = 1;
		filter_count++;
		if(mes._slot != undefined){
			nico.hideMessage(mes);
		}
	}
}

function showInfoOnBtn(btn_name,count){
	main_bar[btn_name].count.text = count;
	main_bar[btn_name].count.setTextFormat(white10_fmt);
	main_bar[btn_name].count._x = 0 - main_bar[btn_name].count._width / 2;
}


//バイナリサーチの判定
//NGIDをソートするのか、新着メッセージをソートするのか、総当りで調べるのか
//NGIDは常にuser_idでソートされていて重複データもないので
//NGIDを優先的に検索するようにしたほうがいいはず
//けっこう適当な判定
function checkSearchMode(new_mes_length, ng_length){
	if(new_mes_length * ng_length >= 10000){
		if(ng_length >= 40){
			return "ng_search";
		}else if(new_mes_length >= 500){
			return "new_mes_search";
		}else{
			return "no_search";
		}
	}else if(new_mes_length * ng_length >= 1000){
		if(ng_length >= 20){
			return "ng_search";
		}else if(new_mes_length >= 250){
			return "new_mes_search";
		}else{
			return "no_search";
		}
	}else{
		return "no_search";
	}
}

function parseCommand(command_line){
	if(command_line == "" || command_line == undefined){
		return undefined;
	}
	var list = command_line.split("&");//ex. place=(ue|shita)
	var param = new Array();
	for(var i=0; i<list.length; i++){
		var temp = new Array();
		temp = list[i].split("=");
		param[temp[0]] = temp[1];//ex. param["place"] = "(ue|shita)"
	}
	var filter = new Array();
	var command = new Array("place","size","color","vpos","limit","mes");
	var null_checker = true;
	for(var i=0; i<command.length; i++){
		if(param[command[i]] != undefined){
			if(param[command[i]].substr(0,1) == "(" && param[command[i]].substr(-1) == ")"){
				param[command[i]] = param[command[i]].substr(1,param[command[i]].length-2);//ex. param["place"] = "ue|shita"
			}
			var status = param[command[i]].split("|");//ex. status[0] = "ue" status[1] = "shita"
			filter[command[i]] = new Array();
			for(var j=0; j<status.length; j++){
				if(command[i] == "limit"){
					if(checkNum(status[j])){
						filter["limit"].push(Number(status[j]));
						null_checker = false;
						break;
					}
				}else if(command[i] == "mes"){
					if(status[j] != ""){
						filter["mes"].push(status[j]);
						null_checker = false;
					}
				}else if(command[i] == "vpos"){
					if(checkNum(status[j])){
						filter[command[i]].push(Number(status[j]));
						null_checker = false;
					}
				}else if(command[i] == "place"){
					if(status[j] == "normal"){
						filter[command[i]].push(0);
						null_checker = false;
					}
					else if(status[j] == "ue"){
						filter[command[i]].push(1);
						null_checker = false;
					}
					else if(status[j] == "shita"){
						filter[command[i]].push(2);
						null_checker = false;
					}
				}else if(command[i] == "size"){
					if(status[j] == "normal"){
						filter[command[i]].push(24);
						null_checker = false;
					}
					else if(status[j] == "big"){
						filter[command[i]].push(39);
						null_checker = false;
					}
					else if(status[j] == "small"){
						filter[command[i]].push(15);
						null_checker = false;
					}
				}else if(command[i] == "color"){
					if(status[j] == "all"){
						filter[command[i]].push("all");
						null_checker = false;
					}
					else if(status[j] == "normal"){
						filter[command[i]].push(16777215);
						null_checker = false;
					}
					else if(status[j] == "red"){
						filter[command[i]].push(16711680);
						null_checker = false;
					}
					else if(status[j] == "green"){
						filter[command[i]].push(65280);
						null_checker = false;
					}
					else if(status[j] == "blue"){
						filter[command[i]].push(255);
						null_checker = false;
					}
					else if(status[j] == "cyan"){
						filter[command[i]].push(65535);
						null_checker = false;
					}
					else if(status[j] == "yellow"){
						filter[command[i]].push(16776960);
						null_checker = false;
					}
					else if(status[j] == "purple"){
						filter[command[i]].push(12583167);
						null_checker = false;
					}
					else if(status[j] == "pink"){
						filter[command[i]].push(16744576);
						null_checker = false;
					}
					else if(status[j] == "orange"){
						filter[command[i]].push(16760832);
						null_checker = false;
					}
					else if(status[j] == "niconicowhite"){
						filter[command[i]].push(13421721);
						null_checker = false;
					}
					else if(status[j] == "white2"){
						filter[command[i]].push(13421721);
						null_checker = false;
					}
					else if(status[j] == "marineblue"){
						filter[command[i]].push(3407868);
						null_checker = false;
					}
					else if(status[j] == "blue2"){
						filter[command[i]].push(3407868);
						null_checker = false;
					}
					else if(status[j] == "madyellow"){
						filter[command[i]].push(10066176);
						null_checker = false;
					}
					else if(status[j] == "yellow2"){
						filter[command[i]].push(10066176);
						null_checker = false;
					}
					else if(status[j] == "passionorange"){
						filter[command[i]].push(16737792);
						null_checker = false;
					}
					else if(status[j] == "orange2"){
						filter[command[i]].push(16737792);
						null_checker = false;
					}
					else if(status[j] == "nobleviolet"){
						filter[command[i]].push(6697932);
						null_checker = false;
					}
					else if(status[j] == "purple2"){
						filter[command[i]].push(6697932);
						null_checker = false;
					}
					else if(status[j] == "elementalgreen"){
						filter[command[i]].push(52326);
						null_checker = false;
					}
					else if(status[j] == "green2"){
						filter[command[i]].push(52326);
						null_checker = false;
					}
					else if(status[j] == "truered"){
						filter[command[i]].push(13369395);
						null_checker = false;
					}
					else if(status[j] == "red2"){
						filter[command[i]].push(13369395);
						null_checker = false;
					}
					else if(status[j] == "black"){
						filter[command[i]].push(0);
						null_checker = false;
					}
					else if(status[j] == "premium"){
						filter[command[i]].push(13421721);
						filter[command[i]].push(3407868);
						filter[command[i]].push(10066176);
						filter[command[i]].push(16737792);
						filter[command[i]].push(6697932);
						filter[command[i]].push(52326);
						filter[command[i]].push(13369395);
						filter[command[i]].push(0);
						null_checker = false;
					}
				}
			}
		}
	}
	if(null_checker){
		return undefined;
	}else{
		return filter;
	}
}

//コメントをローカルcgiにポストする
function sendLocalXML(){
	auto_comment_status = "connecting";
	autoCommentPostIconRotate("start");

	var post_data = new XML();
	var first_no = fwMessages[0]._no;
	var last_no = fwMessages[fwMessages.length - 1]._no;
	var no = local_last_no + 1;//no番以降のコメントを送信したい
	if(first_no > local_last_no){no = first_no;}
	//fwMessagesの_noは小さい順に並んでいるはずなので
	var fwNo = -1;
	while(fwNo == -1 && no <= last_no){//めったにないけどnoが飛び番号で存在しなかった場合のループ
		var fwNo = binarySearch(fwMessages,"_no",no);
		no++;
	}
	//↑fwMessages[fwNo]以降を送信すればいいということになるはず

	var node = post_data.createElement("send");
	node.attributes.total_count = local_total_count;
	node.attributes.last_no = local_last_no;
	node.attributes.name = VIDEO;
	post_data.appendChild(node);
	for(var i=fwNo; i < fwMessages.length; i++){
		var mes = fwMessages[i];
		node = post_data.createElement("chat");
		node.appendChild(post_data.createTextNode(mes._message));
		node.attributes.vpos = mes.vpos;
		if (mes.user_id != undefined && mes.user_id != "") {
			node.attributes.user_id = mes.user_id;
		}
		if (mes.thread != undefined && mes.thread != "") {
			node.attributes.thread = mes.thread;
		}
		if (mes.premium != undefined && mes.premium != "") {
			node.attributes.premium = mes.premium;
		}
		node.attributes.no = mes._no;
		if (mes.name != undefined && mes.name != "") {
			node.attributes.name = mes.name;
		}
		if (mes.mail != undefined && mes.mail != "") {
			node.attributes.mail = mes.mail;
		}
		if (mes.date != undefined && mes.date != "") {
			node.attributes.date = mes.date;
		}
		post_data.appendChild(node);
	}
	post_data.contentType = "text/xml";
	post_data.addRequestHeader("File-Name",VIDEO);//なんとなく

	var result = new XML();//返答を格納する場所の準備
	result.onLoad = function(success){
		var node = result.firstChild;
		if(success && node.nodeName == "result"){
			local_last_no = Number(node.attributes.last_no);
			local_total_count = Number(node.attributes.total_count);
			var add_count = node.attributes.add_count;
			add_count = add_count - 0;
			total_add_count += add_count;
			var T1 = main_bar.auto_comment_info1;
			var T2 = main_bar.auto_comment_info2;
			T1.text = "+" + total_add_count;
			T2.text = local_total_count;
			T1.setTextFormat(black14b_fmt);
			T2.setTextFormat(black14b_fmt);
			T1._x = 682 - T1.textWidth/2;
			T2._x = 682 - T2.textWidth/2;
			main_bar.auto_comment_info_line._visible = true;
		}else{
			nico.AddSystemMessage("コメント自動収集に失敗しました");
			auto_comment_post = false;
		}
		auto_comment_status = "ready";
		autoCommentPostIconRotate("stop");

		if(getflv_status == "wait"){getflv_status = "ready";}
	};

	var crossdomain_dir = comment_server.substring(0,comment_server.lastIndexOf("/")+1);
	System.security.loadPolicyFile(crossdomain_dir + "crossdomain.xml");
	post_data.checkPolicyFile = true;
	post_data.sendAndLoad(comment_server,result);
}

//ローカルcgiに保存済みのコメント情報を要求する
function countLocalXML(video_num){
	auto_comment_status = "connecting";
	autoCommentPostIconRotate("start");

	var post_data = new XML();
	var node = post_data.createElement("count");
	node.attributes.name = video_num;
	post_data.appendChild(node);
	post_data.contentType = "text/xml";
	post_data.addRequestHeader("File-Name",video_num);//なんとなく

	var result = new XML();//返答を格納する場所の準備
	result.onLoad = function(success){
		var node = result.firstChild;
		if(success && node.nodeName == "result"){
			local_last_no = Number(node.attributes.last_no);
			local_total_count = Number(node.attributes.total_count);
			var add_count = node.attributes.add_count;
			add_count = add_count - 0;
			total_add_count += add_count;
			var T1 = main_bar.auto_comment_info1;
			var T2 = main_bar.auto_comment_info2;
			T1.text = "+" + total_add_count;
			T2.text = local_total_count;
			T1.setTextFormat(black14b_fmt);
			T2.setTextFormat(black14b_fmt);
			T1._x = 682 - T1.textWidth/2;
			T2._x = 682 - T2.textWidth/2;
			main_bar.auto_comment_info_line._visible = true;
		}else{
			nico.AddSystemMessage("ローカルコメント自動取得に失敗しました");
			auto_comment_post = false;
		}
		auto_comment_status = "ready";
		autoCommentPostIconRotate("stop");
		if(getflv_status == "wait"){getflv_status = "ready";}
	};

	var crossdomain_dir = comment_server.substring(0,comment_server.lastIndexOf("/")+1);
	System.security.loadPolicyFile(crossdomain_dir + "crossdomain.xml");
	post_data.checkPolicyFile = true;
	post_data.sendAndLoad(comment_server,result);
}

//ローカルcgiにコメントを要求する
function loadLocalXML(video_num,from,to){
	auto_comment_status = "connecting";
	autoCommentPostIconRotate("start");

	var post_data = new XML();
	var node = post_data.createElement("load");
	node.attributes.to = to;
	node.attributes.from = from;
	node.attributes.name = video_num;
	post_data.appendChild(node);
	post_data.contentType = "text/xml";
	post_data.addRequestHeader("File-Name",video_num);//なんとなく

	var result = new XML();//返答を格納する場所の準備
	result.onLoad = function(success){
		var node = result.firstChild;
		if(success){
			nico.ClearMessages();
			nico.Connection.onCMsgGetThreadResult(0, 0, 0, 0);
			nico.onCMsgViewCounter(0);
			var count = 0;
			for(var elem = result.firstChild; elem; elem=elem.nextSibling){
				if(elem.nodeName == "chat"){
					nico.Connection.onCMsgChat(elem.firstChild.nodeValue, elem.attributes.thread, elem.attributes.no, elem.attributes.vpos, elem.attributes.date, elem.attributes.mail, elem.attributes.name, elem.attributes.yourpost, elem.attributes.user_id, elem.attributes.deleted, elem.attributes.premium);
					count++;
				}
			}
			nico.closeInterval();
			nico.AddSystemMessage(from + "～" + to + "までのコメント\(" + count + "件\)を読み込みました");
		}else{
			nico.AddSystemMessage("ローカルコメント読み込みに失敗しました");
			nico.player.play();
		}
		auto_comment_status = "ready";
		autoCommentPostIconRotate("stop");
	};

	var crossdomain_dir = comment_server.substring(0,comment_server.lastIndexOf("/")+1);
	System.security.loadPolicyFile(crossdomain_dir + "crossdomain.xml");
	post_data.checkPolicyFile = true;
	post_data.sendAndLoad(comment_server,result);
}

//xmlファイルをコメントとして読み込んでみる
function loadLocalXML2 (xml_url){
	auto_comment_status = "connecting";
	autoCommentPostIconRotate("start");

	var result = new XML();//返答を格納する場所の準備
	result.onLoad = function(success){
		var node = result.firstChild;
		if(success && node.nodeName == "packet"){
			node = node.firstChild;
		}
		if(success){
			nico.ClearMessages();
			nico.Connection.onCMsgGetThreadResult(0, 0, 0, 0);
			nico.onCMsgViewCounter(0);
			var count = 0;
			for(var elem = node; elem; elem=elem.nextSibling){
				if(elem.nodeName == "chat"){
					nico.Connection.onCMsgChat(elem.firstChild.nodeValue, elem.attributes.thread, elem.attributes.no, elem.attributes.vpos, elem.attributes.date, elem.attributes.mail, elem.attributes.name, elem.attributes.yourpost, elem.attributes.user_id, elem.attributes.deleted, elem.attributes.premium);
					count++;
				}
			}
			nico.closeInterval();
			nico.AddSystemMessage("xmlファイルのコメント\(" + count + "件\)を読み込みました");
		}else{
			nico.AddSystemMessage("ローカルコメント読み込みに失敗しました");
			nico.player.play();
		}
		auto_comment_status = "ready";
		autoCommentPostIconRotate("stop");
	};

	result.Load(xml_url);
}


//マウスホイール
//そのつど個別にaddとremoveしたほうがいいんじゃないかと思いつつ、そのまんま
var wheel_listener = new Object();
wheel_listener.onMouseWheel = function(delta,target){
	if(test_mode){
		if(Key.isDown(17)){
			alert_js(target + "/D"+target.getDepth()+"/W"+target._width+"/H"+target._height+"/XS"+target._xscale+"/YS"+target._yscale+"/X"+target._x+"/Y"+target._y);
		}else{
			mylist_js(target);
		}
	}
	while(target != undefined){
		if(target == nico.videowindow && mouse_wheel){break;}
		else if(target == screen && mouse_wheel){break;}
		else if(target == pref_menu.input_mouse_backward){break;}
		else if(target == pref_menu.label_mouse_backward){break;}
		else if(target == pref_menu.input_mouse_forward){break;}
		else if(target == pref_menu.label_mouse_forward){break;}
		else if(target == link_thumb){break;}
		else if(target == ngid_menu.mes){break;}
		target = target._parent;
	}
	if(target == nico.videowindow || target == screen){
		if(screen.auto_play_info._visible){
			clearAutoPlayInfo();
		}
		if(mouse_reverse){delta = 0 - delta;}
		var now = nico.player.__get__playheadtime();
		var boost = 0;
//		if(mouse_wheel_interval < 5){boost = 5;}
		if(delta<0){
			var jump_time = now + mouse_forward + boost;
			if(jump_time < nico.player._contentLength - 5){
				nico.player.__set__playheadtime(jump_time);
			}else{
				nico.player.__set__playheadtime(nico.player._contentLength - 5);
			}
		}else if(delta>0){
			nico.player.__set__playheadtime(now - mouse_backward - boost);
		}
		var state = nico.player.__get__state();
		if(state != "playing"){nico.player.play();}
		setCheckPlayingInterval();
	}else if(target == pref_menu.input_mouse_backward || target == pref_menu.label_mouse_backward){
		if(delta < 0){
			var num = Number(pref_menu.input_mouse_backward.text) - 1;
		}else{
			var num = Number(pref_menu.input_mouse_backward.text) + 1;
		}
		if(num < 1){num = 1;}
		mouse_backward = num;
		pref_menu.input_mouse_backward.text = num;
		mouse_wheel_so.data.backward = mouse_backward;
		mouse_wheel_so.flush();
	}else if(target == pref_menu.input_mouse_forward || target == pref_menu.label_mouse_forward){
		if(delta < 0){
			var num = Number(pref_menu.input_mouse_forward.text) - 1;
		}else{
			var num = Number(pref_menu.input_mouse_forward.text) + 1;
		}
		if(num < 1){num = 1;}
		mouse_forward = num;
		pref_menu.input_mouse_forward.text = num;
		mouse_wheel_so.data.forward = mouse_forward;
		mouse_wheel_so.flush();
	}else if(target == link_thumb){
		if(delta < 0){
			updateLinkThumb("next",-1,-1);
		}else if(delta > 0){
			updateLinkThumb("before",-1,-1);
		}
	}else if(target == ngid_menu.mes){
		if(delta < 0){
			scrollNGIDMenu(1);
		}else if(delta > 0){
			scrollNGIDMenu(-1);
		}
	}
};
Mouse.addListener(wheel_listener);


//flvplayerのfunctionを上書きしたり、addListenerしたり
//めんどうなのでほとんどコピペしてインデントなし
//どうせflvplayerが更新されたら変更しないとだめだし・・・
function replaceFunction(){
			//なんとなくバーを太く
			if(wide_seek_bar){
				nico.controller.Seeker_mc._height = 50;
				nico.controller.Seeker_mc.Knob_mc._height = 6;
				nico.controller.Seeker_mc.Knob_mc._width = 12;
			}

			//カウンターを下にちょっとずらす
			nico.header.Comments._y += 7;
			nico.header.Members._y += 7;

			//スクリーン上のコメントクリック用
			nico.videowindow.onPress = function(){
				if(screen.auto_play_info._visible){
					clearAutoPlayInfo();
					nico.player.play();
				}else{
					var id = searchID();
					emphID(id);
				}
			};

//自動再生を禁止する処理
    nico.OpenInput = function() {
      if (nico.ready) {
        if (nico.ChatInput._visible) {
          nico.inputArea.ChatSendButton._visible = true;
        }
        return undefined;
      }
      nico.ready = true;
      nico.UpdateChatInput();
      nico.inputArea.OverlayCheck._visible = true;
      nico.inputArea.OverlayCheckLabel._visible = true;
      nico.inputArea.ReplayCheck._visible = true;
      nico.inputArea.ReplayCheckLabel._visible = true;
      nico.Overlay._visible = !nico.inputArea.OverlayCheck.selected;
      nico.SingleLineCheck._visible = true;
      if (e) {
        nico.DeleteLabel._visible = true;
        nico.DeleteButton._visible = true;
      }
			//↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓
			if(auto_play){
				nico.player.play();
			}else{
				setAutoPlayInfo();
			}
			//↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑
    };

//メッセージ生成の時の処理
    nico.Connection.onCMsgChat = function (message, thread, no, vpos, date, mail, name, yourpost, user, deleted, premium) {
      if (nico.first_resno == 0) {
        nico.first_resno = no;
        if (nico.selectTab == nico.TAB_WAYBACK) {
          nico.setWaybackforWeb(nico.wayback_time);
        }
      }
      if (nico.last_resno == no) {
        nico.MsgGetNow = false;
        nico.tabmenu.enabled = true;
        nico.inputArea.enabled = true;
      }
      if (nico.NoMessages) {
        nico.ClearMessages();
      }
      if (deleted == nico.MESSAGE_MANAGE_DELETE || deleted == nico.MESSAGE_USER_DELETE && e == undefined) {
        nico.writeLogList();
        return undefined;
      }
      if (message == undefined) {
        message = "";
      }
      vpos /= nico.VPOS_FACTOR;
      no = Number(no);
      date = Number(date);
      if (nico.MyPost == no) {
        yourpost = true;
        nico.MyPost = undefined;
      }
      var v4 = 0;
      var v5 = 0;
      i = nico.Messages.length - 1;
      while (i >= 0) {
        var v2 = nico.Messages[i];
        var v1 = v2._no;
			//↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓
			//新着コメントはfwMessagesに盲目的にpushしていくので
			//今保持しているのコメントよりも古いコメントがきたら捨てる
			//502バグ？(502エラーになると前回取得したコメントXMLがまた送られてくる)の対処もかねる
			if(v1 >= no){return undefined;}
			//↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑
        if (v1 == no) {
          nico.HideMessage(v2);
          v5 = 1;
          v4 = i;
          break;
        }
        if (v1 < no) {
          v4 = i + 1;
          break;
        }
        --i;
      }

      var v11 = nico.CreateMessage(no, vpos, name, mail, message, yourpost, int(deleted), premium);
      nico.Messages.splice(v4, v5, v11);
			//↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓
			//コメントが０の場合、こいつが送られてきてnico.Messages[0]に鎮座する
			//Connection.onCMsgChat(" コメントがない以下略", "", 0, 0, 0, "ue", "注意", 1);
			if(no != 0){//↑のやつじゃなかったら
				if(user == undefined || user == ""){user = "0";}//idなしを0にする
				fwMessages.push({no: nico.Messages.length - 1, _no: no, user_id: user, _message: message, _vpos: vpos, vpos: vpos * nico.VPOS_FACTOR, date: date, premium: premium, name: name, mail: mail, thread: thread});

				if(add_id){//add_idならAddChatLogする前にメッセージにID付与
					if(premium){
						message = "P[" + user.substr(0,id_length) + "] " + message;
					}else{
						message = "[" + user.substr(0,id_length) + "] " + message;
					}
				}
			}
			//↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑

			//↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓
			if(list_mode == "normal"){
				nico.AddChatLog(v4, v5, no, vpos, message, mail, name, date, deleted);
			}
			//↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑
      if (nico.last_resno == no) {
        nico.writeLogList();
      }
      if (nico.Connection.isHttp()) {
        if (!nico.ThreadIntervalShort) {
          clearInterval(nico.ThreadIntervalID);
          var v6 = nico.HTTP_INTERVAL_SHORT_ECONOMY;
          if (nico.PremiumFlag == 1) {
            v6 = nico.HTTP_INTERVAL_SHORT;
          }
          nico.ThreadIntervalID = setInterval(nico.onThreadInterval, v6);
          nico.ThreadIntervalShort = true;
        }
      }
      nico.NoMessages = false;
    };

//動画を開くときにローカルファイルを読み込ませる
    nico.OpenPlayer = function(thread_id, url, l, link) {
      nico.CurrentThreadID = thread_id;
      nico.loadingImage._visible = false;
      nico.player.__set___visible(true);
      nico.player.__set__autoPlay(false);
      nico.ClearOverlay();
      nico.ContentLength = l;
      nico.Stats.req = getTimer();
//↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓
if(local_file_found){
	url = local_server_name[local_server_num] + VIDEO + ".flv";
	showInfoOnMainBar("ローカルFLVから再生します");
	main_bar.icon_local._x = Math.round(nico.header._x + nico.header.icon_narrow._x);
	main_bar.icon_local._y = Math.round(nico.header._y + nico.header.icon_narrow._y + fwOffsetY);
	main_bar.icon_local._visible = true;
}
//↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑
      nico.player.load(url, l);
      nico.linkURL = link;
    };

//動画の長さにMessagesが収められてしまうのを防ぐ
//動画の最後のあたりのコメントのvposがいじられてしまうのを防ぐ
//メモ CreateMessageの最後のほうのvpos
//        nico.player.__get__totalTime = function () {
//↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓
//return this._contentLength + 3;
//↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑
//        };

}

function showInfoOnMainBar(info){
	main_bar.main_info.text = info;
	main_bar.main_info.setTextFormat(black12_fmt);
	main_bar.main_info._x = 290 - main_bar.main_info.textWidth/2;
}

//スクリーン上の情報表示
function showInfoOnScreen(info,sec){
	if(sec == undefined){sec = 60;}
	screen.wrapper_info.text = info;
	screen.wrapper_info.setTextFormat(red24b_fmt);
	screen.wrapper_info._x = nico.videowindow._x + nico.videowindow.video._width - screen.wrapper_info.textWidth;
	screen.wrapper_info._visible = true;
	setShowInfoOnScreenInterval(sec);
}

function setAutoPlayInfo(){
	nico.videowindow._alpha = 50;
	screen.auto_play_info._visible = true;
	checkPlayerStart();
}

function clearAutoPlayInfo(){
	nico.videowindow._alpha = 100;
	screen.auto_play_info._visible = false;
}

function quickNGIDMode(mode){
	if(mode == "on"){
		main_bar.base.onRelease = function(){
			var xm = main_bar._xmouse;
			if(xm > main_bar.main_info._x && xm < main_bar.main_info._x + main_bar.main_info._width){
				var ym = main_bar._ymouse;
				if(ym > main_bar.main_info._y && ym < main_bar.main_info._y + main_bar.main_info._height){
					loglist_menu.add_id._visible = false;
					cand_ng_id = deleteRepField(cand_ng_id,"user_id",false);
					updateFilter("add_id");
				}
			}
		};
	}else if(mode == "off"){
		main_bar.base.onRelease = function(){};
	}
}
//完全ローカル再生の実験
//ニュースを読み込みにいくが同一ドメインなので404が帰ってくる
//めんどうなのでつぶしてない
//他の通信はしないはず
function playLocalFLV(f){
	showInfoOnMainBar("完全ローカルモードで再生します");
	auto_comment_post = false;

	nico.OpenPlayer(undefined,f,12345.6789,undefined);

	playLocalXML();
}

function playLocalXML(){
	clearInterval(playLocalXML_TimerID);
	if(wx != undefined){
		loadLocalXML2(unescape(wx));
	}else{
		var dur = nico.player._contentLength;
		//動画読み込んでduration得られるまで待つ
		if(dur == 12345.6789){
			playLocalXML_TimerID = setInterval(playLocalXML,100);
			return;
		}else{
			//読み込み番号の決定↓
			max_comments = Math.round(dur / 60 * 100);//5分で500 10分で1000ぐらい
			if(max_comments > limit_comments){max_comments = limit_comments;}
			if(max_comments < 250){max_comments = 250;}
			if(local_from == "random"){
				if(local_total_count < max_comments){
					local_from = 1;
					local_to = local_total_count;
				}else{
					local_from = Math.floor(Math.random() * (local_total_count - max_comments + 1)) + 1;
					local_to = local_from + max_comments - 1;
				}
			}else if(local_from <= 0){
				local_to = local_total_count + local_from;
				local_from = local_to - max_comments + 1;
			}else{
				local_to = local_from + max_comments - 1;
			}
			if(local_from < 0){local_from = 1;}
			if(local_to < 0){local_to = 1;}
			if(local_from > local_total_count){local_from = local_total_count;}
			if(local_to > local_total_count){local_to = local_total_count;}
			loadLocalXML(VIDEO,local_from,local_to);
		}
	}
}

//リンク生成
function addLink(cand_links){
	for(var i=0; i<cand_links.length; i++){
		if(links[0].length < max_auto_link){//max_auto_link以下なら
			links[0].push(cand_links[i]);//後ろに新しいの追加
			updateLinkThumb("add",-1,-1);
			if(show_info){
				showInfoOnScreen("Auto Link", 120);
			}
		}
	}
}

//自動リンク検索 sm123456 am123456 fz123456
//半角のみ
function searchLink(mode){
	var headers = new Array("sm","am","fz","ca");
	var cand_links = new Array();
	for (var i=0; i<headers.length; i++){
		var link = headers[i];
		var ary;
		if(mode == "tags"){ary = video_tags;}
		else if(mode == "comments"){ary = nico.MessageSlots;}
		for(var j=0; j < ary.length; j++){
			var original_mes, mes;
			if(mode == "tags"){original_mes = video_tags[j];}
			else if(mode == "comments"){original_mes = nico.MessageSlots[j]._text.text;}
			mes = original_mes;
			if(mes != ""){
				while(mes.IndexOf(headers[i]) >= 0){
					var numbers = mes.substr(mes.IndexOf(headers[i])+2, 8);
					for(var k=0; k < numbers.length; k++){
						if(checkNum(numbers.charAt(k))){
							link += numbers.charAt(k);
						}
						else{
							break;
						}
					}
					if(link.length >= 3 && link != VIDEO){
						var rep_flag = false;//すでに同じリンクがないか重複チェック
						for(var k=0; k<links[0].length; k++){
							if(links[0][k].number == link){
								rep_flag = true;
								break;
							}
						}
						if(!reg_flag){
							for(var k=0; k<cand_links.length; k++){
								if(cand_links[k].number == link){
									rep_flag = true;
									break;
								}
							}
						}
						if(!rep_flag){
							if(mode == "tags"){
								original_mes = "[タグ] " + original_mes;
								cand_links.push({number: link, message: original_mes, status:"順番待ち"});
							}else if(mode == "comments"){
								for(var k=0; k<nico.Messages.length; k++){
									if(nico.Messages[k]._slot == j){
										cand_links.push({number: link, message: original_mes, user_id:fwMessages[k].user_id, status:"順番待ち"});
										break;
									}
								}
							}
						}
					}
					link = headers[i];
					mes = mes.substr(mes.IndexOf(headers[i])+2);
				}
			}
		}
	}	
	if(cand_links.length>0){return cand_links;}
	else{return undefined;}
}

//ローカル再生
//ものすごい適当にそれっぽいのを並べてみただけ
//function tryToPlayCache(){
//	var url = local_server_name[local_server_num] + VIDEO + ".flv";
//	nico.player.load(url,120);
//nico.ClearMessages();
//nico.OpenInput();
//nico.connectBoard(true);
//	nico.player.play();
//	showInfoOnScreen(url, 120);
//}

//ダウンロード
function downloadFLV(){
	if (local_file_found){
	getURL(local_server_name[local_server_num] + VIDEO + ".flv");
//		doJavaScript("location.href = \"" + local_server_name[local_server_num] + VIDEO + ".flv\";");
	} else {
		getURL(nico.o.url, "_blank");
//		getURL(nico.o.url);
//		doJavaScript("location.href = \"" + nico.o.url + "\";");
		setDownLoadInterval(600);
	}
}

//残りcheck_repeat_threshold秒を切ったらタイマー設置
function checkRepeat(){
	var loaded_bytes = nico.player.stream_ns.bytesLoaded;
	if(loaded_bytes < 100000){return;}
	var now = nico.player.__get__playheadtime();
	var last = nico.player._contentLength;
	if(end_time > 0){last = end_time;}
//	if (last < now && last != 0){
//		auto_repeat_status = "start";
//		startRepeat();
//		return;
	if( last - now < check_repeat_threshold && last != 0){
		//タイマー起動(なんとなく0.5秒ほど遅らせる)
		auto_repeat_status = "start";
		repeat_timerID = setInterval(startRepeat , Math.round((last - now)*1000) + 500);
		return;
	}
}

//リピート再生のスタート処理
function startRepeat(){
	clearInterval(repeat_timerID);
	auto_repeat_status = "ready";
	if(auto_repeat){
		var now = nico.player.__get__playheadtime();
		if(now < 1){//デフォのくりかえし機能が先に発動してしまったっぽい場合
			if(show_info){
				showInfoOnScreen("Repeat-",120);
			}
		}else{
			nico.player.__set__playheadtime(0);
			setCheckPlayingInterval();
			if(show_info){
				if(end_time > 0){
					showInfoOnScreen("Repeat+",120);
				}else{
					showInfoOnScreen("Repeat",120);
				}
			}
		}
	}
}

//field_nameでソート(sortOn(field_name,16))されたsorted_aryから文字列sを探し出す
//sorted_ary[n][field_name] == sならnを返す
//みつからない場合は-1を返す
function binarySearch(sorted_ary,field_name,s){
	var high = sorted_ary.length - 1;
	var low = 0;
	var mid = Math.floor((low+high)/2);
	var result_num = -1;
	while(high >= low){
		if(s == sorted_ary[mid][field_name]){
			result_num = mid;
			break;
		}
//		var tmp_ary = new Array({tmp:s},{tmp:sorted_ary[mid][field_name]});
//		tmp_ary.sortOn("tmp",16);
//		if(tmp_ary[0].tmp == s){
//sortOn(field_name,16)されてるなら、↑みたいにしなくて
//↓みたいにstring1 < string2とかやっても問題ないようだ
		if(s < sorted_ary[mid][field_name]){
			high = mid - 1;
		}else{
			low = mid + 1;
		}
		mid=Math.floor((low+high)/2);
	}
	return result_num;
}

//binarySearchの検索結果が複数あるかもしれない版
//結果は配列で返されるので、みつからない場合は配列.length==0で判断できる
//numが一つしかない、もしくはnumの有無を確認したいだけなら、こっちを使う必要はない
function binarySearchS(sorted_ary,field_name,s){
	var result_num = binarySearch(sorted_ary,field_name,s);
	var result_ary = new Array();
	if(result_num != -1){
		var i = result_num - 1;
		while(sorted_ary[i][field_name] == s){
			result_ary.unshift(i);
			i--;
		}
		i = result_num;
		while(sorted_ary[i][field_name] == s){
			result_ary.push(i);
			i++;
		}
	}
	return result_ary;
}

//渡された配列のfield_nameの重複を削除して配列を返す
//field_nameの数値の小さい順に並べて返される
//sort_status=trueならすでにソートされているものとして扱う
function deleteRepField(ary,field_name,sort_status){
	if(!sort_status){
		ary.sortOn(field_name,16);
	}
	var result_ary = new Array();
	if(ary.length>0){
		result_ary.push(ary[0]);
		for(var i=1; i<ary.length; i++){
			if(ary[i][field_name] != ary[i-1][field_name]){
				result_ary.push(ary[i]);
			}
		}
	}
	return result_ary;
}

//NGIDの各種削除処理
//sort_status=trueならすでにdateの大きい順にソートされているものとして扱う
//最終的にdateフィールドの大きい順にならべた配列を返す(はず)
function deleteExpID(ary,sort_status){
	if(!sort_status){
		ary.sortOn("date",16|2);//dateの数値の大きい順
	}
	var result_ary = ary.slice();
	if(result_ary.length > max_ng_id){//NGIDが規定数を超えていたら
		while(result_ary.length > max_ng_id){
			result_ary.pop();//はみでたお尻のヤツを削除
		}
	}
	var myDate = new Date();
	var now = myDate.getTime();
	for(var i=result_ary.length-1; i >= 0; i--){
		if(now - result_ary[i].date >= ng_id_expires){//期限切れを削除
			result_ary.pop();
		}else{
			break;
		}
	}
	return result_ary;
}

//文字列sのold_keyをnew_keyに入れ替える
//複数keyを削除したい場合はold_keyに配列を渡す
//new_key=""にすれば、単純な文字削除に使える
function replaceSentence (s, old_key, new_key) {
	var ary = new Array();
	if(typeof(old_key) == "object"){
		for(var i=0; i<old_key.length; i++){
			ary = s.split(old_key[i]);
			s = ary.join(new_key);
		}
	}else if(typeof(old_key) == "string"){
		ary = s.split(old_key);
		s = ary.join(new_key);
	}
	return s;
}

//文字列s1とs2がどの程度類似しているか、すごい適当な判定
//似たようなコメントを投下しつづける荒らしIDの判定に使おうかと思いつつ
//職人のコメントにモロに誤爆するので見送り
function compareSentence (s1, s2) {
	var shortSt, longSt;
	if(s1.length >= s2.length){shortSt = s2; longSt = s1;}
	else{shortSt = s1; longSt = s2;}

	var count = 0;
	for(var i=0; i<shortSt.length; i++){
		var pos = longSt.indexOf(shortSt.substr(i,1));
		if(pos >= 0){
			longSt = longSt.substring(0, pos - 1) + longSt.substring(pos + 1);
			count++;
		}
	}
	var rate = Math.round(count / shortSt.length * 100);
	return rate;
}

//こんな方法でいいのか数字判定
function checkNum(s){
	if(s == "" || s == undefined){
		return false;
	}
	s = s.toString();
	var result = true;
	for(var i=0; i<s.length; i++){
		if(s.charCodeAt(i) < 48 || s.charCodeAt(i) > 57 ){
			result = false;
			break;
		}
	}
	return result;
}

//flvplayer_containerの高さ変更
//オミトロンのフィルターでやるようにした
//function JS_setFLVPlayerSize(){
//	var javascript_command = "
//		document.getElementById('flvplayer_container').style.height='480px';
//	";
//	doJavaScript(javascript_command);
//}

function JS_getTitle(){
	var javascript_command = "
		var htag = document.getElementsByTagName('h1');
		var title = htag[0].firstChild.firstChild.nodeValue;
		document.getElementById('flvplayer').SetVariable('video_title',title);
	";
	doJavaScript(javascript_command);
}

//javascriptで登録タグをvideo_tagsに入れてもらう
//video_tagsに入れられるまでちょっと時間がかかる
function JS_getVideoTags(){
	var javascript_command = "
		var vtag = document.getElementById('video_tags');
		var vtags = vtag.firstChild.firstChild;
		var i=0,j=0;
		while(i<22 && vtags != undefined){
			if(vtags.hasChildNodes()){
				document.getElementById('flvplayer').SetVariable('video_tags.'+j,vtags.firstChild.nodeValue);
				j++;
			}
			vtags = vtags.nextSibling;
			i++;
		}
		document.getElementById('flvplayer').SetVariable('video_tags.'+j,'doJavaScript_END');
	";
	doJavaScript(javascript_command);
}

//JavaScriptでマイリストっぽいのをに入れてもらう
//うｐ主のコメント欄の判定が面倒なので、
//どうせ読み込み時に1回しか処理しないし<a>タグを総当り
//				var value = atags[i].firstChild.nodeValue;
function JS_getMyLists(){
	var javascript_command = "
		var atags = document.getElementsByTagName('a');
		var j=0;
		for(var i=0; i<atags.length; i++){
			if(atags[i].hasChildNodes()){
				var value = atags[i].getAttribute('href');
				if(value.match(/mylist\\\/[0-9]+\\\//)){
					document.getElementById('flvplayer').SetVariable('my_lists.'+j, value);
					j++;
				}
			}
		}
		document.getElementById('flvplayer').SetVariable('my_lists.'+j, 'doJavaScript_END');
	";
	doJavaScript(javascript_command);
}

//getNextHighestDepthがなんだかうまく使えないので
//window_aryのインスタンスの順番を変えずに、指定のインスタンスを最上部にもってくる
function goTopDepth(path){
	var window_ary = new Array("pref_menu","ngid_menu","link_thumb");
	var depth_ary = new Array();
	for(var i=0; i<window_ary.length; i++){//ウィンドウの深度を得る
		if(_root[window_ary[i]] != undefined){
			depth_ary.push({name:window_ary[i], depth:_root[window_ary[i]].getDepth()});
		}
	}
	depth_ary.sortOn("depth",16);//深度の深い順に
	var window_found = false;
	for(var i=0; i<depth_ary.length; i++){
		if(window_found){
			path.swapDepths(_root[depth_ary[i].name]);
		}
		if(path._name == depth_ary[i].name){
			window_found = true;
		}
	}
};


//おもにデバッグ用
function doJavaScript(s){
	if(use_javascript){
		getURL("javascript:" + s + "void(0);");
	}else{
		return undefined;
	}
}
//デバッグ用　JSでalertだす Operaだとマルチバイト文字は化ける
function alert_js(s){
	if(use_javascript){
		doJavaScript("alert('" + s + "');");
	}else{
		return undefined;
	}
}
//デバッグ用　JSでmylist_add_statusのところ書き換え Operaだとマルチバイト文字は化ける
function mylist_js(s,plus){
	if(use_javascript){
		if(plus){
			doJavaScript("document.getElementById('mylist_add_status').innerHTML += '" + s + "';");
		}else{
			doJavaScript("document.getElementById('mylist_add_status').innerHTML = '" + s + "';");
		}
	}else{
		return undefined;
	}
}


//タイムライン？というかタイマー？
//こんなやり方正しいのかどうか知らないが・・
//getflvするにしろrepeatするにしろMessagesの更新にしろ
//flvplayer書き換えとかやると本家バージョンアップの時のチェックが面倒すぎるので
//onEnterFrameいっぱいつくって定期的に監視しつつ、いらなくなったらdeleteするのが楽でいい気がする
createEmptyMovieClip("timeLine",30000);

//flvplayer読み込みからgetflv開始までの監視用
timeLine.createEmptyMovieClip("getflv",1);
timeLine.getflv.onEnterFrame = function(){
	if(getflv_status == "ready"){
		var total = nico.getBytesTotal();
		var loaded = nico.getBytesLoaded();
		if(total > 0 && total == loaded){//flvplayer.swfの読み込み終了
			replaceFunction();//いくつかのfunctionを上書きしてしまう
			if(wv != undefined){
				playLocalFLV(unescape(wv));
				main_bar.icon_local._x = nico.header._x + nico.header.icon_narrow._x;
				main_bar.icon_local._y = nico.header._y + nico.header.icon_narrow._y - 60;
				main_bar.icon_local._visible = true;
			}else{
				startJavaScript();
				setAutoRepeatInterval();
				setAutoLinkInterval();
				setAutoCommentPostInterval();
				nico.v = VIDEO;
				nico.ad = AD;
				nico.us = US;
				nico.getVideo(VIDEO);
			}
			getflv_status = "done";
			delete this.onEnterFrame;//もういらないので消去
		}
	}
};

//getflv開始からjavascriptの返答待ちまで
//IE6だと順番に実行しないとダメだった
//めんどうなのでチェックしないで10フレームおきに順番に盲目的に実行
timeLine.createEmptyMovieClip("start_js",11);
function startJavaScript(){
	var limit_interval = 1800;//最大で何フレーム待つか
	var order = 1;
	timeLine.start_js.onEnterFrame = function(){
		limit_interval--;
		if(check_interval % 10 == 0){
			if(order == 1){JS_getVideoTags();}
			if(order == 2){JS_getMyLists();}
			if(order == 3){JS_getTitle();}
//			if(order == 4){JS_setFLVPlayerSize();}
			if(video_tags[video_tags.length-1] == "doJavaScript_END"){
				video_tags.pop();
				var cand_links = searchLink("tags");
				if(cand_links != undefined){
					addLink(cand_links);
				}
			}
			if(my_lists[my_lists.length-1] == "doJavaScript_END"){
				my_lists.pop();
				if(my_lists.length > 0){
					main_bar.link._visible = true;
					for(var i=2; i>=0; i--){
						if(my_lists[i] != undefined){
							updateLinkTab(i+1,false);
						}
					}
					//↓自動リンクが先に作成されてなさそうなら、アクティブにする
					if(links[0].length == 0){//自動リンクは作成されてないはず
						updateLinkTab(1,true);
						links_num = [1,0];
						updateLinkThumb("update",links_num[0],links_num[1]);
					}
				}
			}
			order++;
			if(limit_interval < 0){
				delete this.onEnterFrame;
			}
		}
	};
}

//自動コメントアイコン回転用
timeLine.createEmptyMovieClip("auto_comment_icon_rotate",20);
function autoCommentPostIconRotate(mode){
	if(mode == "start"){
		timeLine.auto_comment_icon_rotate.onEnterFrame = function(){
			main_bar.auto_comment_icon._rotation += 10;
		};
	}
	if(mode == "stop"){
		delete timeLine.auto_comment_icon_rotate.onEnterFrame;
		main_bar.auto_comment_icon._rotation = 0;
	}
}

//スクリーン情報消すまでの監視　showInfoOnScreen内で使用
timeLine.createEmptyMovieClip("info_on_screen",30);
function setShowInfoOnScreenInterval(num){
	var interval = num;//numフレーム後に消す
	timeLine.info_on_screen.onEnterFrame = function(){
		interval--;
		if(interval < 0){
			screen.wrapper_info._visible = false;
			interval = undefined;
			delete this.onEnterFrame;
		}
	};
}
//シーク先で再生状態になっているか監視(マウスホイールとかリピートとかで)
timeLine.createEmptyMovieClip("check_playing",40);
function setCheckPlayingInterval(){
	var interval = 29;
	var debug = "";
	timeLine.check_playing.onEnterFrame = function(){
		interval--;
		if(interval % 10 == 0){
			var state = nico.player.__get__state();
			if(state == "paused" || state == "end"){
				nico.player.play();
				debug += state + "->play ";
			}else if(state == "buffering" || state == "seeking"){
				nico.player.play();
				debug += state + "->done ";
				interval = -1;
			}else{
				debug += state + " ";
			}
		}
		if(interval < 0){
			interval = undefined;
			delete this.onEnterFrame;
			if(test_mode){
//				mylist_js(debug);
			}
		}
	};
}

//リピート終点入力時のシークバーによる時間入力監視
timeLine.createEmptyMovieClip("end_time_input",50);
function setEndTimeInputInterval(){
	timeLine.end_time_input.onEnterFrame = function(){
		if(check_interval % 10 == 0){
			end_time_input.window.now.text = nico.player.__get__playheadtime();
			end_time_input.window.now.setTextFormat(black14b_fmt);
			end_time_input.window.now._x = -100 - end_time_input.window.now._width;
		}
		if(end_time_input == undefined){
			delete this.onEnterFrame;
		}
	};
}

//リピート監視
timeLine.createEmptyMovieClip("auto_repeat",60);
function setAutoRepeatInterval(){
	timeLine.auto_repeat.onEnterFrame = function(){
		if(check_interval % 30 == 0){
			if(auto_repeat && auto_repeat_status == "ready"){
				checkRepeat();
			}else if(!auto_repeat){
				delete this.onEnterFrame;
			}
		}
	};
}

//自動リンク監視
timeLine.createEmptyMovieClip("auto_link",70);
function setAutoLinkInterval(){
	timeLine.auto_link.onEnterFrame = function(){
		if(check_interval % 30 == 0){
			if(auto_link && links.length <= max_auto_link-1){
				var cand_links = searchLink("comments");
				if(cand_links != undefined){
					addLink(cand_links);
				}
			}else{
				delete this.onEnterFrame;
			}
		}
	};
}

//自動コメント収集監視
timeLine.createEmptyMovieClip("auto_comment_post",80);
function setAutoCommentPostInterval(){
	timeLine.auto_comment_post.onEnterFrame = function(){
		if(check_interval % 60 == 0){
			if(auto_comment_post){
				if(auto_comment_status == "ready"){
					if(getflv_status == "done"){
						if(local_last_no < fwMessages[fwMessages.length - 1]._no){
							sendLocalXML();
						}
					}
				}
			}else{
				delete this.onEnterFrame;
			}
		}
	};
}

//自動コメント取得禁止
//2箇所書き換えるのがめんどうなので・・・
//ThreadIntervalIDを監視する
timeLine.createEmptyMovieClip("auto_comment_get",90);
var last_clear_time = 0;
clearThreadIntervalID();
function clearThreadIntervalID(){
	timeLine.auto_comment_get.onEnterFrame = function(){
		if(check_interval % 60 == 0){
			if(!auto_comment_get){
				if(nico.ThreadIntervalID != undefined){
					nico.closeInterval();
				}
//			}else{
//				delete this.onEnterFrame;
			}
		}
	};
}

//ダウンロードボタンを消す
timeLine.createEmptyMovieClip("download",100);
function setDownLoadInterval(num){
	var interval = num;
	main_bar.download._visible = false;
	timeLine.download.onEnterFrame = function(){
		interval--;
		if(interval < 0){
			main_bar.download._visible = true;
			interval = undefined;
			delete this.onEnterFrame;
		}
	};
}
//実験 拡大使ってる人用　多少はレイアウトがましになるハズ？
timeLine.createEmptyMovieClip("style",110);
timeLine.style.onEnterFrame = function(){
	if(chech_interval %10 == 0){
		main_bar._x = nico.header._x - 4;
//		screen.wrapper_info._xscale = nico.videowindow._xscale;
//		screen.wrapper_info._yscale = nico.videowindow._yscale;
		loglist_menu._visible = nico.tabmenu._visible;
	}
};

//サムネの読み込みリトライ
//buffer_aryを定期的に監視して、サムネが入ってたらloading_aryに移し変えて読み込みする
//buffer_ary{list_num, thumb_num, url, timeout1, timeout2, retry, status}
//404なのかサーバーが重くてエラーなのかの判定をしていないので
//404でもキッチリretry_count回数接続しにいくのが難点
timeLine.createEmptyMovieClip("get_thumb",120);
timeLine.get_thumb.onEnterFrame = function(){
	var max_connection = 5;//最大同時接続数
	var retry_count = 3;//リトライ回数
	var timeout1 = 3;//タイムアウト(ほぼ秒) getBytesTotal==-1がこれだけ続くとエラーと判定
	var timeout2 = 60;//タイムアウト(ほぼ秒) getBytesTotal==0がこれだけ続くともう止める

	if(check_interval % 10 == 0){
		if(loading_ary.length < max_connection && buffer_ary.length > 0){
			loading_ary.push(buffer_ary[0]);
			buffer_ary.splice(0,1);
		}
		if(loading_ary.length == 0){
			return;
		}
		for(var i=0; i<loading_ary.length; i++){
			var l_num = loading_ary[i].list_num;
			var t_num = loading_ary[i].thumb_num;
			var thumb_window = link_thumb["thumb"+l_num+"_"+t_num];
			if(loading_ary[i].status == "ready"){
				thumb_window.createEmptyMovieClip("thumb",1);
				thumb_window.thumb.loadMovie(loading_ary[i].url);
				loading_ary[i].status = "loading";
				links[l_num][t_num].thumb_status = "読み込み中 " + (loading_ary[i].retry+1) + "回目";
				updateLinkThumb("update",links_num[0],links_num[1]);
			}
			
			var total = thumb_window.thumb.getBytesTotal();
			var loaded = thumb_window.thumb.getBytesLoaded();
			//↓エラーっぽい場合
			if(total < 0){
				loading_ary[i].timeout1 += 1;
				if(loading_ary[i].timeout1 > timeout1 * 60 / 10){
					loading_ary[i].timeout1 = 0;
					loading_ary[i].timeout2 = 0;
					loading_ary[i].retry += 1;
					if(loading_ary[i].retry >= retry_count){
						links[l_num][t_num].thumb_status = "読み込み失敗";
						updateLinkThumb("update",links_num[0],links_num[1]);
						loading_ary.splice(i,1);
						i--;
					}else{
						thumb_window.thumb.removeMovieClip();
						loading_ary[i].status = "ready";
						links[l_num][t_num].thumb_status = "順番待ち";
						updateLinkThumb("update",links_num[0],links_num[1]);
					}
				}
			//↓読み込みされたっぽいサムネの処理
			}else if(total > 0 && total == loaded){
				links[l_num][t_num].thumb_status = "";
				updateLinkThumb("update",links_num[0],links_num[1]);
				loading_ary.splice(i,1);
				i--;
			//↓返答待ちっぽいサムネの処理
			}else{
				loading_ary[i].timeout2 += 1;
				if(loading_ary[i].timeout2 > timeout2 * 60 / 10){
					links[l_num][t_num].thumb_status = "読み込み失敗(なんか変です)";
					updateLinkThumb("update",links_num[0],links_num[1]);
					loading_ary.splice(i,1);
					i--;
				}
			}
		}
	}
};

//<title>タグをいろいろいじる
timeLine.createEmptyMovieClip("change_title",130);
var bytes_ary = new Array();
var total_bytes_backup = 0;
timeLine.change_title.onEnterFrame = function(){
	var titleJSCom = "document.getElementsByTagName('h1')[0].firstChild.firstChild.nodeValue";
	if(!change_title){
		delete this.onEnterFrame;
		return;
	}
	if(check_interval % 60 == 0){
		//動画に接続できなかったと思われる
		//bytesTotalやbytesLoadedからは識別不能っぽいので
		if(nico.player.dummy_active){
			delete this.onEnterFrame;
			doJavaScript("document.title = 'Error?';");
			if(test_mode){
				doJavaScript("window.location.reload();");
			}
			return;
		}
		var total = nico.player.stream_ns.bytesTotal;
		var now = nico.player.stream_ns.bytesLoaded;
		var checkDate = new Date();
		var checkTime = checkDate.getTime();
		if(total_bytes_backup < total){
			total_bytes_backup = total;
		}
		if((total <= now && total > 0) || local_file_found){//読み込み中と思われる
			delete this.onEnterFrame;
			if(local_file_found){
				doJavaScript("document.title = " + titleJSCom + ";");
			//↓totalサイズが、なぜか以前の値より小さく変更されてしまったっぽい時
			//読み込み中に回線切断とかの時はこうなるっぽい
			}else if(total < total_bytes_backup){
				var rate = Math.round(now / total_bytes_backup *100);
				doJavaScript("document.title = 'Disconnect(" + rate + "%)';");
			}else{
				doJavaScript("document.title = " + titleJSCom + ";");
			}
			return;
		}
		bytes_ary.push({bytes:now, time:checkTime});
		if(bytes_ary.length > 10){
			bytes_ary.splice(0,1);
		}
		if(bytes_ary.length >= 2){
			var last_num = bytes_ary.length - 1;
			var kbps = (bytes_ary[last_num].bytes - bytes_ary[0].bytes) / (bytes_ary[last_num].time - bytes_ary[0].time) * 1000 / 1024 * 8;
			kbps = Math.round(kbps);
			if(total > 0){
				var rate = Math.round(now / total *100);
			}else{
				var rate = 0;
			}
			doJavaScript("document.title = '" + kbps + "kbps(" + rate + "%)'+" + titleJSCom + ";");
		}
	}
};

//ローカルFLVがあるかどうかチェック
timeLine.createEmptyMovieClip("check_flv",140);
timeLine.check_flv.onEnterFrame = function(){
	if(check_interval % 10 == 0 && check_flv_status == "ready"){
		var crossdomain_dir = local_server_index[local_server_num].substring(0,local_server_index[local_server_num].lastIndexOf("/")+1);
		System.security.loadPolicyFile(crossdomain_dir + "crossdomain.xml");
		flv_index.checkPolicyFile = true;
		flv_index.load(local_server_index[local_server_num]);
		check_flv_status = "connecting";
	}
};
var flv_index = new LoadVars();
flv_index.onData = function(src){
	var search_result = src.indexOf(VIDEO + ".flv");
	//いいかげんなチェック
	if(src != undefined && search_result >= 0){//flvが見つかった
		local_file_found = true;
		delete timeLine.check_flv.onEnterFrame;
		if(auto_comment_post){
			//auto_comment_postならgetflv止めたまま保存済みコメントのラスト番号を調べにいく
			countLocalXML(VIDEO);
			return;
		}else{
			getflv_status = "ready";//getflv開始
		}
	}else{//flvが見つからない
		if(local_server_num < local_server_index.length - 1){//次のサーバーをチェック
			local_server_num++;
			check_flv_status = "ready";
			return;
		}else{//最後のサーバーまでチェックしたので普通にニコニコに接続
			//ローカルFLVがないときは、自動コメント収集禁止にしておく(自分の好みで)
			auto_comment_post = false;
			delete timeLine.check_flv.onEnterFrame;
			getflv_status = "ready";//getflv開始
		}
	}
};

//マイリストを見ているときに自動リンクが反応したら、タブをフラッシュ？させて知らせる
timeLine.createEmptyMovieClip("flash_tab",150);
function flashTab(mode){
	if(mode == "start"){
		timeLine.flash_tab.onEnterFrame = function(){
			if(check_interval % 30 == 0){
				if(link_thumb.tab0.over_lay_red._visible){
					link_thumb.tab0.over_lay_red._visible = false;
				}else{
					link_thumb.tab0.over_lay_red._visible = true;
				}
			}
		};
	}else if(mode == "stop"){
		delete timeLine.flash_tab.onEnterFrame;
		link_thumb.tab0.over_lay_red._visible = false;
	}
}

//サムネをホイールクリックでバックグラウンドで開く
//一応動くが、問題点が二つ
//１ホイールクリックでのウィンドウオープンはブラウザのポップアップブロックにひっかかる
//ポップアップブロック解除しないとだめだ
//２ホイールクリックではFlashにfocusが移らない
//WheelPlusとかマウ筋とか使ってると、
//ホイールシークだけで操作してFlashのボタン押さない時とか割とよくあると思うんだが
//そういう状態で自動リンクが反応したりすると
//いったんwrapper上の関係ないところを左クリックしてfocusうつしたあと
//おもむろにホイールクリックとかしないとウィンドウが開かない
//またバックグラウンドで開くと、今のウィンドウから一旦focusが外れるらしいので
//またFlashからfocusが外れる
//実用性が低すぎる
//どう考えてもサムネ右下のBボタン押したほうが楽だ
var wheel_click_prev = false;
timeLine.createEmptyMovieClip("key_check",160);
timeLine.key_check.onEnterFrame = function(){
	var wheel_click_status = Key.isDown(4);
	if(wheel_click_prev != wheel_click_status){
		if(wheel_click_status == true){
			var xm = link_thumb._xmouse;
			var ym = link_thumb._ymouse;
			if(ym>20 && ym<120 && xm>0 && xm<130){
				link_thumb.open_blur.onRelease();
			}
		}
		wheel_click_prev = wheel_click_status;
	}
};

//自動再生禁止時にプレイヤーがスタートするのを監視
timeLine.createEmptyMovieClip("check_player_start",170);
function checkPlayerStart(){
	timeLine.check_player_start.onEnterFrame = function(){
		var state = nico.player.__get__state();
		if(state == "playing" || state == "connectionError" || nico.player.dummy_active){
			clearAutoPlayInfo();
			delete this.onEnterFrame;
		}
	};
}

//_root毎フレームずっと処理し続ける用
_root.onEnterFrame = function() {
	updateFilter("check");
	check_interval --;
	if(check_interval < 0){
		check_interval = 599;
	}
};

EOT;
//メインスクリプト終わり

$movie->add(new SWFAction($MainScript));
$movie->nextFrame();
$movie->save("flvplayer_wrapper.swf");

header("Content-Type: application/x-shockwave-flash");
//header("Cache-Control: no-cache");//普通はサーバーが勝手に送る
//header("Pragma: no-cache");
$movie->output();

?>
